<?php

include 'functions.php';
$conn = connectDB();

mysql_select_db('dbfuneral', $conn);

$deceasedID = $_REQUEST['dec'];
$deceased_FName = $_REQUEST['deceased_FName'];
$deceased_LName = $_REQUEST['deceased_LName'];
$deceased_Address = $_REQUEST['deceased_Address'];
$deceased_City = $_REQUEST['deceased_City'];
$deceased_State = $_REQUEST['deceased_State'];
$deceased_Zip = $_REQUEST['deceased_Zip'];
$deceased_Gender = $_REQUEST['deceased_Gender'];
$deceased_Passing = $_REQUEST['deceased_Passing'];
$contact_FName = $_REQUEST['contact_FName'];
$contact_LName = $_REQUEST['contact_LName'];
$contact_Relation = $_REQUEST['contact_Relation'];
$contact_Email = $_REQUEST['contact_Email'];
$contact_Phone = $_REQUEST['contact_Phone'];
$funeral_Home_Name = $_REQUEST['funeral_Home_Name'];
$funeral_Home_Address = $_REQUEST['funeral_Home_Address'];
$funeral_Home_City = $_REQUEST['funeral_Home_City'];
$funeral_Home_State = $_REQUEST['funeral_Home_State'];
$funeral_Home_Zip = $_REQUEST['funeral_Home_Zip'];
$wake_Location = $_REQUEST['wake_Location'];
$wake_fh_date = $_REQUEST['wake_fh_date'];
$wake_fh_start = $_REQUEST['wake_fh_start'];
$wake_fh_end = $_REQUEST['wake_fh_end'];
$wake_ch_date = $_REQUEST['wake_ch_date'];
$wake_ch_start = $_REQUEST['wake_ch_start'];
$wake_ch_end = $_REQUEST['wake_ch_end'];
$mass_Date = $_REQUEST['mass_Date'];
$mass_Time = $_REQUEST['mass_Time'];
$body_Burial = $_REQUEST['body_Burial'];
$cemetery_Notes = $_REQUEST['cemetery_Notes'];
$priest_FName = $_REQUEST['priest_FName'];
$priest_LName = $_REQUEST['priest_LName'];
$bereavement_FName = $_REQUEST['bereavement_FName'];
$bereavement_LName = $_REQUEST['bereavement_LName'];

$formOk = true;

$data = array();
$data[0] = 1;
$data[1] = array();

//If the funeral home is selected for the wake, put blank info for the church 
if($wake_Location['value'] == 'FH'){
	$wake_ch_date['value'] = '0000-00-00';
	$wake_ch_start['value'] = '00:00:00';
	$wake_ch_end['value'] = '00:00:00';
}
//If the church is selected for the wake, put blank info for the funeral home
else if($wake_Location['value'] == 'CH'){
	$wake_fh_date['value'] = '0000-00-00';
	$wake_fh_start['value'] = '00:00:00';
	$wake_fh_end['value'] = '00:00:00';
}

//Go through every value that's been passed and check if any of them are blank
foreach($_POST as $input){
	//Ignore the cemetery notes since it's optional
	if($input['id'] = 'txtbx_edit_cemetery_Notes'){
		continue;
	}
	//If the Funeral Home is selected for the wake, ignore the church inputs
	else if(
		$wake_location['value'] == 'FH' 
		&& ($input['id'] == 'select_edit_date_wake_CH' 
		|| $input['id'] == 'select_edit_time_wake_start_CH' 
		|| $input['id'] == 'elect_edit_time_wake_end_CH')){
		
		continue;
	}
	//If the church is selected for the wake, ignore the funeral home inputs
	else if(
		$wake_location['value'] == 'CH' 
		&& ($input['id'] == 'select_edit_date_wake_FH' 
		|| $input['id'] == 'select_edit_time_wake_start_FH' 
		|| $input['id'] == 'elect_edit_time_wake_end_FH')){
		
		continue;
	}	
		
	else if($input['value'] == ''){
		$formOk = false;
		$data[0] = -1;
		array_push($data[1], $input['id']);
	}
}

if (!filter_var($contact_Email['value'], FILTER_VALIDATE_EMAIL)) {
	$formOk = false;
	
	$data[0] = -1;
	array_push($data[1], "<b>x</b> Error: Please enter a valid email for primary contact<br>");
}

if(!preg_match("/^\d{3}-\d{3}-\d{4}$/", $contact_Phone['value'])){
	$formOk = false;
	
	$data[0] = -1;
	array_push($data[1], "<b>x</b> Error: Please enter a valid phone number for primary contact<br>(xxx-xxx-xxxx)<br>");
} 

if($wake_Location['value'] == 'FH' || $wake_Location['value'] == 'BT'){
	$today = date("Y-m-d");
	$selectedDate = date("Y-m-d", strtotime($wake_fh_date['value']));
	
	if($selectedDate < $today){
		$formOk = false;
		
		$data[0] = -1;
		array_push($data[1], "<b>x</b> Error: Please enter a wake date that wasn't before today (funeral home)<br>");
	}
	
	if(strtotime($wake_fh_end['value']) <= strtotime($wake_fh_start['value'])){
		$formOk = false;
		
		$data[0] = -1;
		array_push($data[1], "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (funeral home)<br>");
	}
}

if($wake_Location['value'] == 'CH' || $wake_Location['value'] == 'BT'){
	$today = date("Y-m-d");
	$selectedDate = date("Y-m-d", strtotime($wake_ch_date['value']));
	
	if($selectedDate < $today){
		$formOk = false;
		
		$data[0] = -1;
		array_push($data[1], "<b>x</b> Error: Please enter a wake date that wasn't before today (church)<br>");
	}
	
	if(strtotime($wake_ch_end['value']) <= strtotime($wake_ch_start['value'])){
		$formOk = false;
		
		$data[0] = -1;
		array_push($data[1], "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (church)<br>");
	}
}

$today = date("Y-m-d");
$selectedDate = date("Y-m-d", strtotime($mass_Date['value']));

if($selectedDate < $today){
	$formOk = false;
	
	$data[0] = -1;
	array_push($data[1], "<b>x</b> Error: Please enter a mass date that wasn't before today)<br>");
}



if($formOk){
	
	$updateDeceased = "
		UPDATE Deceased
		SET
			vchar_dec_First_Name = '" . mysql_escape_string($deceased_FName['value']) . "'"
			. ", vchar_dec_Last_Name = '" . mysql_escape_string($deceased_LName['value']) . "'"
			. ", vchar_dec_Street_Address = '" . mysql_escape_string($deceased_Address['value']) . "'"
			. ", vchar_dec_City = '" . mysql_escape_string($deceased_City['value']) . "'"
			. ", char_dec_State = '" . mysql_escape_string($deceased_State['value']) . "'"
			. ", vchar_dec_Zipcode = '" . mysql_escape_string($deceased_Zip['value']) . "'"
			. ", char_gender = '" . mysql_escape_string($deceased_Gender['value']) . "'"
			. ", dt_date_Of_Death = '" . mysql_escape_string($deceased_Passing['value']) . "'"
			. ", char_location = '" . mysql_escape_string($wake_Location['value']) . "'"
			. ", dt_date_Of_Wake_FH = '" . mysql_escape_string($wake_fh_date['value']) . "'"
			. ", time_start_Of_Wake_FH = '" . mysql_escape_string($wake_fh_start['value']) . "'"
			. ", time_end_Of_Wake_FH = '" . mysql_escape_string($wake_fh_end['value']) . "'"
			. ", dt_date_Of_Wake_CH = '" . mysql_escape_string($wake_ch_date['value']) . "'"
			. ", time_start_Of_Wake_CH = '" . mysql_escape_string($wake_ch_start['value']) . "'"
			. ", time_end_Of_Wake_CH = '" . mysql_escape_string($wake_ch_end['value']) . "'"
			. ", dt_date_Of_Mass = '" . mysql_escape_string($mass_Date['value']) . "'"
			. ", time_start_Of_Mass = '" . mysql_escape_string($mass_Time['value']) . "'"
			. ", boolean_if_Cemetery = '" . mysql_escape_string($body_Burial['value']) . "'"
			. ", longtext_cemetery_Text = '" . mysql_escape_string($cemetery_Notes['value']) . "'"
		. " WHERE int_deceased_ID = '" . mysql_escape_string($deceasedID['value']) . "'";
	
	$deceasedResult = mysql_query($updateDeceased);
	
	if($deceasedResult){
		
		$editContact = "
			UPDATE Primary_Contact
			SET
				vchar_primCont_First_Name = '" . mysql_escape_string($contact_FName) . "'
				, vchar_primCont_Last_Name = '" . mysql_escape_string($contact_LName) . "'
				, char_relation_To_Deceased = '" . mysql_escape_string($contact_Relation) . "'
				, nvarchar_primCont_Email = '" . mysql_escape_string($contact_Email) . "'
				, vchar_primCont_Phone_Num = '" . mysql_escape_string($contact_Phone) . "'
			WHERE int_Deceased_ID = '" . mysql_escape_string($deceasedID) . "'";
			
		
		$contactResult = mysql_query($editContact);
		
		if($contactResult){

			$editFuneralHome = "
				UPDATE Funeral_Home
				SET
					vchar_funeral_Home_Name = '" . mysql_escape_string($funeral_Home_Name['value']) . "'
					, vchar_FH_Address = '" . mysql_escape_string($funeral_Home_Address['value']) . "'
					, vchar_FH_City = '" . mysql_escape_string($funeral_Home_City['value']) . "'
					, vchar_FH_State = '" . mysql_escape_string($funeral_Home_State['value']) . "'
					, vchar_FH_Zipcode = '" . mysql_escape_string($funeral_Home_Zip['value']) . "'
				WHERE int_deceased_ID = '" . mysql_escape_string($deceasedID['value']) . "'";

			$funeralHomeResult = mysql_query($editFuneralHome);

			if($funeralHomeResult){

				$editPriestBMNames = "
					UPDATE Funeral_Mass_Plan
					SET
						vchar_Priest_First_Name = '" . mysql_escape_string($priest_FName['value']) . "'
						, vchar_Priest_Last_Name = '" . mysql_escape_string($priest_LName['value']) . "'
						, vchar_BM_First_Name = '" . mysql_escape_string($bereavement_FName['value']) . "'
						, vchar_BM_Last_Name = '" . mysql_escape_string($bereavement_LName['value']) . "'
					WHERE int_deceased_ID = '" . mysql_escape_string($deceasedID['value']) . "'";

				$priesBMResult = mysql_query($editPriestBMNames);

				if(!$priesBMResult){
					$data[0] = -1;
					array_push($data[1], "<b>x</b> Error: " . mysql_error() . "</br>");
				}
			}
			else{
				$data[0] = -1;
				array_push($data[1], "<b>x</b> Error: " . mysql_error() . "</br>");
			}
		}
		else{
			$data[0] = -1;
			array_push($data[1], "<b>x</b> Error: " . mysql_error() . "</br>");
		}
	}
	else{
		$data[0] = -1;
		array_push($data[1], "<b>x</b> Error: " . mysql_error() . "</br>");
	}
}

closeDB($conn);

echo json_encode($data);

?>