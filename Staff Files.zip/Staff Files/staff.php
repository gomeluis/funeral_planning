<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">

<!-- Bootstrap links -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<!-- End Bootstrap links -->

<!-- FontAwesome JS links -->
<script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
<!-- End FontAwesome JS links -->

<!-- Custom style links -->
<link rel="stylesheet" type="text/css" href="Styles/styles.css" />
<!-- End custom style links -->

<!-- jQuery links -->
<script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<!-- End jQuery links -->

<!-- Google Font links -->
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- End Google Font links -->

<!-- Custom javascript links -->
<script src="Js/scripts.js"></script>

<title>Form Name</title> <!-- Change later -->
</head>
<body>

<div class="container"> <!-- container -->
	<div class="row"> <!-- row -->
		<div class="col-12"> <!-- col-12 -->
			<div class="w-100" id="divLogoHeader">
				<img class="img-fluid" src="images/logo-church-header.png" alt="Saint Juliana Parish" id="imgLogoHeader">
			</div>
		</div> <!-- /col-12 -->

		<div class="col-12">
			<nav class="navbar navbar-toggleable-md navbar-inverse bg-faded nav-green">
				<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav">
						<a class="nav-item nav-link active" href="#">
                           	<i class="fas fa-plus-square"></i> Create Record
                        </a>
                    </div>
                    <div class="navbar-nav">
						<a class="nav-item nav-link active" href="searchRecord.php?st=dec">
                           	<i class="fas fa-address-book"></i> Search Deceased Record
                        </a>
                    </div>
                    <div class="navbar-nav">
						<a class="nav-item nav-link active" href="searchRecord.php?st=fmp">
                           	<i class="fas fa-book"></i> Search Funeral Mass Plan
                        </a>
					</div>
				</div>
                <a class="navbar-brand navbar-right" href="#">Welcome: 'Staff Member'</a>
			</nav>
		</div>
	</div> <!-- /row -->
		
	<div id="MainForm">
       	<div class="row"> <!-- row -->
        	<div class="col-12"  id="deceasedColHeader"> <!-- col-12 -->
				<br>
				<h3 class="text-center">Welcome 'Staff Member'</h3>
				<br>
			</div> <!-- /col-12 -->		
            <div class="col-12">
            	<p class="push-left push-right">
                	Below you can do one of three things. Create a new deceased record, search a deceased record, or search a funeral mass plan
                </p>
            </div>
            <div class="col-12 col-md-4">
            	<div class="push-left">
                	<a href="create.php"><button class="btn btn-lg btn-block btn-green">Create Record</button></a>
                </div>
                <br>
            </div>
            <div class="col-12 col-md-4">
                <div>
                	<a href="searchRecord.php?st=dec"><button class="btn btn-lg btn-block btn-green">Search Deceased Record</button></a>
                </div>
                <br>
            </div>
            <div class="col-12 col-md-4">
                <div class="push-right">
                	<a href="searchRecord.php?st=fmp"><button class="btn btn-lg btn-block btn-green">Search Funeral Mass Plan</button></a>
                </div>
                <br>
            </div>
        </div> <!-- /row -->
        <br>
            
        <div id="footer">
            <?php
            include "functions.php";
            getFooter();
            ?>
        </div>
			
	</div> <!-- /MainForm -->              
</div> <!-- /container -->
</body>
</html>	