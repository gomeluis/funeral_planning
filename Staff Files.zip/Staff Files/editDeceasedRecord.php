<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">

<!-- Bootstrap links -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<!-- End Bootstrap links -->

<!-- FontAwesome JS links -->
<script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
<!-- End FontAwesome JS links -->

<!-- Custom style links -->
<link rel="stylesheet" type="text/css" href="Styles/styles.css" />
<!-- End custom style links -->

<!-- jQuery links -->
<script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<!-- End jQuery links -->

<!-- Google Font links -->
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- End Google Font links -->

<!-- Custom javascript links -->
<script src="Js/scripts.js"></script>

<title>Form Name</title> <!-- Change later -->
</head>
<body>

<div class="container"> <!-- container -->
	<div class="row"> <!-- row -->
		<div class="col-12"> <!-- col-12 -->
			<div class="w-100" id="divLogoHeader">
				<img class="img-fluid" src="images/logo-church-header.png" alt="Saint Juliana Parish" id="imgLogoHeader">
			</div>
		</div> <!-- /col-12 -->

		<div class="col-12">
			<nav class="navbar navbar-toggleable-md navbar-inverse bg-faded nav-green">
				<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav">
						<a class="nav-item nav-link active" href="create.php">
                           	<i class="fas fa-plus-square"></i> Create Record
                        </a>
                    </div>
                    <div class="navbar-nav">
						<a class="nav-item nav-link active" href="searchRecord.php?st=dec">
                           	<i class="fas fa-address-book"></i> Search Deceased Record
                        </a>
                    </div>
                    <div class="navbar-nav">
						<a class="nav-item nav-link active" href="searchRecord.php?st=fmp">
                           	<i class="fas fa-book"></i> Search Funeral Mass Plan
                        </a>
					</div>
				</div>
                <a class="navbar-brand navbar-right" href="#">Welcome: 'Staff Member'</a>
			</nav>
		</div>
	</div> <!-- /row -->
    
    
    <?php
	
	include 'functions.php';
	$conn = connectDB();
	
	mysql_select_db('dbfuneral', $conn);
	
	$query = "
		SELECT DC.int_deceased_ID AS DCID, 
			DC.vchar_dec_First_Name AS DCFName,
			DC.vchar_dec_Last_Name AS DCLName, 
			DC.char_gender AS DCGender, 
			DC.vchar_dec_Street_Address AS DCAddress, 
			DC.vchar_dec_City AS DCCity, 
			DC.char_dec_State AS DCState, 
			DC.vchar_dec_Zipcode AS DCZip, 
			DC.char_location AS DCLocation,
			PC.vchar_primCont_First_Name AS PCFName,
			PC.vchar_primCont_Last_Name AS PCLName, 
			PC.nvarchar_primCont_Email AS PCEmail, 
			PC.char_relation_To_Deceased AS PCRelation, 
			PC.vchar_primCont_Phone_Num AS PCPhone, 
			DC.dt_Date_Of_Death AS DCPassingDate, 
			DC.dt_date_Of_Wake_FH AS DCDateWakeFH, 
			DC.time_start_Of_Wake_FH AS DCStartTimeWakeFH, 
			DC.time_end_Of_Wake_FH AS DCEndTimeWakeFH, 
			DC.dt_date_Of_Wake_CH AS DCDateWakeCH, 
			DC.time_start_Of_Wake_CH AS DCStartTimeWakeCH, 
			DC.time_end_Of_Wake_CH AS DCEndTimeWakeCH, 
			DC.dt_date_Of_Mass AS DCMassDate, 
			DC.time_start_Of_Mass AS DCMassTime, 
			DC.longtext_cemetery_Text AS DCCemetery, 
			FMP.vchar_Priest_First_Name AS FMPPriestFName,
			FMP.vchar_Priest_Last_Name AS FMPPriestLName, 
			FMP.vchar_BM_First_Name AS FMPBMFName,
			FMP.vchar_BM_Last_Name AS FMPBMLName,
			FH.vchar_funeral_Home_Name AS FHName,
			FH.vchar_FH_Address AS FHAddress,
			FH.vchar_FH_City AS FHCity,
			FH.vchar_FH_State AS FHState,
			FH.vchar_FH_Zipcode AS FHZip,
			DC.boolean_if_Cemetery AS DCIfCemetery
			 
		FROM 
			Primary_Contact AS PC 
				INNER JOIN Deceased AS DC ON PC.int_deceased_ID = DC.int_deceased_ID 
				INNER JOIN Funeral_Mass_Plan AS FMP ON DC.int_deceased_ID = FMP.int_deceased_ID 
				INNER JOIN Funeral_Home AS FH ON FH.int_deceased_ID = FMP.int_deceased_ID
		WHERE DC.int_deceased_ID=" . $_REQUEST['dec'];
		
	$results = mysql_query($query) or die(mysql_error());	
	$numRows = mysql_num_rows($results);
	
	/*Check if the number of results for the query results 0
		if so, display appropriate message.
		Else, Continue generating the results.*/
	if($numRows <= 0){
		
		$DCFullName = "Nothing to show here";
	}
	else{
		while ($row = mysql_fetch_array($results)) {
			$DCFName = $row['DCFName'];
			$DCLName = $row['DCLName'];
			$DCGender = $row['DCGender'];
			$DCAddress = $row['DCAddress'];
			$DCCity = $row['DCCity'];
			$DCState = $row['DCState'];
			$DCZip = $row['DCZip'];
			
			$PCFName = $row['PCFName'];
			$PCLName = $row['PCLName'];
			$PCEmail = $row['PCEmail'];
			$PCRelation = $row['PCRelation'];
			$PCPhone = $row['PCPhone'];
			
			$DCPassingDate = $row['DCPassingDate'];
			$DCLocationWake = $row['DCLocation'];
			$DCDateWakeFH = $row['DCDateWakeFH'];
			$DCStartTimeWakeFH = $row['DCStartTimeWakeFH'];
			$DCEndTimeWakeFH = $row['DCEndTimeWakeFH'];
			$DCDateWakeCH = $row['DCDateWakeCH'];
			$DCStartTimeWakeCH = $row['DCStartTimeWakeCH'];
			$DCEndTimeWakeCH = $row['DCEndTimeWakeCH'];
			$DCMassDate = $row['DCMassDate'];
			$DCMassTime = $row['DCMassTime'];
			$DCIfCemetery = $row['DCIfCemetery'];
			$DCCemetery = $row['DCCemetery'];
			
			$FMPPriestFName = $row['FMPPriestFName'];
			$FMPPriestLName = $row['FMPPriestLName'];
			$FMPBMFName= $row['FMPBMFName'];
			$FMPBMLName= $row['FMPBMLName'];
			
			$FHName = $row['FHName'];
			$FHAddress = $row['FHAddress'];
			$FHCity = $row['FHCity'];
			$FHState = $row['FHState'];
			$FHZip = $row['FHZip'];
		}
	}		
	
	?>
		
	<div id="MainForm" name="EditPageMainForm">
       	<div class="row"> <!-- row -->
        	<div class="col-12"  id="deceasedColHeader"> <!-- col-12 -->
				<br>
			</div> <!-- /col-12 -->		
            
        </div> <!-- /row -->
        <br>
        
        <form method="post" id="edit_Deceased_Record_Form">
            <div class="row"> <!-- row -->
                <div class="col-12"> <!-- col-12 -->
                    <?php
                    if(!$_GET){
                        
                        echo '<p>Sorry, nothing to see here.</p><br></div>';
                    }
                    else{ 
                    ?>
                        
                        
                    <h2 class="push-left push-right">Deceased Information</h2>
                    <br>
                    <br>
                </div> <!-- /col-12 -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        First Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="First Name" id="txtbx_edit_deceased_FName" value="<?php echo $DCFName; ?>" >	
                        <input type="hidden" value="Please insert the deceased's first name" id="err_txtbx_edit_deceased_FName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Last Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Last Name" id="txtbx_edit_deceased_LName" value="<?php echo $DCLName; ?>" >	
                        <input type="hidden" value="Please insert the deceased's last name" id="err_txtbx_edit_deceased_LName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Address
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Address" id="txtbx_edit_deceased_Address" value="<?php echo $DCAddress; ?>" >	
                        <input type="hidden" value="Please insert the deceased's address" id="err_txtbx_edit_deceased_Address">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
            
            <div class="row"> <!-- row -->
            	<div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        City
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
            	<div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="City" id="txtbx_edit_deceased_City" value="<?php echo $DCCity; ?>" >	
                        <input type="hidden" value="Please insert the deceased's city" id="err_txtbx_edit_deceased_City">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->  
            
            <div class="row"> <!-- row -->
				<div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                    	State
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
            	<div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
						<select required class="form-control" id="select_edit_deceased_State">
                        	<?php echo '<option selected value="' . $DCState . '" selected>' . getFullState($DCState) . '</option>'; ?>
							<option value="" disabled>Select an option</option>
							<option value="AL">Alabama</option>
                            <option value="AK">Alaska</option>
                            <option value="AZ">Arizona</option>
                            <option value="AR">Arkansas</option>
                            <option value="CA">California</option>
                            <option value="CO">Colorado</option>
                            <option value="CT">Connecticut</option>
                            <option value="DE">Delaware</option>
                            <option value="DC">District Of Columbia</option>
                            <option value="FL">Florida</option>
                            <option value="GA">Georgia</option>
                            <option value="HI">Hawaii</option>
                            <option value="ID">Idaho</option>
                            <option value="IL">Illinois</option>
                            <option value="IN">Indiana</option>
                            <option value="IA">Iowa</option>
                            <option value="KS">Kansas</option>
                            <option value="KY">Kentucky</option>
                            <option value="LA">Louisiana</option>
                            <option value="ME">Maine</option>
                            <option value="MD">Maryland</option>
                            <option value="MA">Massachusetts</option>
                            <option value="MI">Michigan</option>
                            <option value="MN">Minnesota</option>
                            <option value="MS">Mississippi</option>
                            <option value="MO">Missouri</option>
                            <option value="MT">Montana</option>
                            <option value="NE">Nebraska</option>
                            <option value="NV">Nevada</option>
                            <option value="NH">New Hampshire</option>
                            <option value="NJ">New Jersey</option>
                            <option value="NM">New Mexico</option>
                            <option value="NY">New York</option>
                            <option value="NC">North Carolina</option>
                            <option value="ND">North Dakota</option>
                            <option value="OH">Ohio</option>
                            <option value="OK">Oklahoma</option>
                            <option value="OR">Oregon</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="RI">Rhode Island</option>
                            <option value="SC">South Carolina</option>
                            <option value="SD">South Dakota</option>
                            <option value="TN">Tennessee</option>
                            <option value="TX">Texas</option>
                            <option value="UT">Utah</option>
                            <option value="VT">Vermont</option>
                            <option value="VA">Virginia</option>
                            <option value="WA">Washington</option>
                            <option value="WV">West Virginia</option>
                            <option value="WI">Wisconsin</option>
                            <option value="WY">Wyoming</option>
						</select>
                        <input type="hidden" value="Please insert the deceased's state" id="err_select_edit_deceased_State">
					</div>
					<br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                      
                     
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Zipcode
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="number" min="10000" max="99999" class="form-control" placeholder="Zipcode" id="txtbx_edit_deceased_Zip" value="<?php echo $DCZip; ?>">	
                        <input type="hidden" value="Please insert the deceased's zipcode" id="err_txtbx_edit_deceased_Zip">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->    
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Gender
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <select class="form-control" id="select_edit_deceased_Gender" required>
                        	<option value="" disabled>Select an option</option>
							<option value="M" <?php if($DCGender == "M") echo selected ?> >Male</option>
							<option value="F" <?php if($DCGender == "F") echo selected ?>>Female</option>
						</select>
                        <input type="hidden" value="Please insert the deceased's gender" id="err_txtbx_edit_deceased_Gender">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->    
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Date of Passing
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="date" class="form-control" placeholder="mm/dd/yyyy" value="<?php echo $DCPassingDate;?>" id="date_edit_deceased_Passing">
                        <input type="hidden" value="Please insert the deceased's gender" id="err_date_edit_deceased_Passing">
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->  
            
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Primary Contact Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row -->  
                  
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        First Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="First Name" id="txtbx_edit_contact_FName" value="<?php echo $PCFName; ?>" >	
                        <input type="hidden" value="Please insert the deceased's first name" id="err_txtbx_edit_contact_FName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->     
            
             <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Last Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Last Name" id="txtbx_edit_contact_LName" value="<?php echo $PCLName; ?>" >	
                        <input type="hidden" value="Please insert the deceased's last name" id="err_txtbx_edit_contact_LName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                   
                  
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Relation
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <select required class="form-control" id="select_edit_contact_Relation">
                        	<option value="" disabled>Select an option</option>
                            <?php echo '<option value="' . $PCRelation . '" selected>' . $PCRelation . '</option>'; ?>
							<option value="spouse">Spouse</option>
							<option value="son">Son</option>
							<option value="daughter">Daughter</option>
							<option value="grandson">Grandson</option>
							<option value="grandaughter">Grandaughter</option>
							<option value="father">Father</option>
                            <option value="mother">Mother</option>
							<option value="grandfather">Grandfather</option>
                            <option value="grandmother">Grandmother</option>
                            <option value="brother">Brother</option>
							<option value="sister">Sister</option>
							<option value="other">Other</option>
						</select>
                        <input type="hidden" value="Please insert the deceased's relation" id="err_select_edit_contact_Relation">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->           
                  
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Email
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="email" class="form-control" placeholder="Email" id="txtbx_edit_contact_Email" value="<?php echo $PCEmail; ?>" >	
                        <input type="hidden" value="Please insert the deceased's email" id="err_txtbx_edit_contact_Email">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->      
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Phone
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="tel" class="form-control" placeholder="Phone" id="txtbx_edit_contact_Phone" value="<?php echo $PCPhone; ?>" >	
                        <input type="hidden" value="Please insert the deceased's phone" id="err_txtbx_edit_contact_Phone">
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                           
            
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Wake and Funeral Home Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row -->              
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Name" id="txtbx_edit_fh_Name" value="<?php echo $FHName; ?>" >	
                        <input type="hidden" value="Please insert the name of the funeral home" id="err_txtbx_edit_fh_Name">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->     
            
             <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Address
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Address" id="txtbx_edit_fh_Address" value="<?php echo $FHAddress; ?>" >	
                        <input type="hidden" value="Please insert the address of the funeral home" id="err_txtbx_edit_fh_Address">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->         
            
             <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        City
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="City" id="txtbx_edit_fh_City" value="<?php echo $FHCity; ?>" >	
                        <input type="hidden" value="Please insert the city of the funeral home" id="err_txtbx_edit_fh_City">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->   
            
            <div class="row"> <!-- row -->
				<div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                    	State
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
            	<div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
						<select required class="form-control" id="select_edit_fh_State">
                        	<?php echo '<option selected value="' . $FHState . '" selected>' . getFullState($FHState) . '</option>'; ?>
							<option value="" disabled>Select an option</option>
							<option value="AL">Alabama</option>
                            <option value="AK">Alaska</option>
                            <option value="AZ">Arizona</option>
                            <option value="AR">Arkansas</option>
                            <option value="CA">California</option>
                            <option value="CO">Colorado</option>
                            <option value="CT">Connecticut</option>
                            <option value="DE">Delaware</option>
                            <option value="DC">District Of Columbia</option>
                            <option value="FL">Florida</option>
                            <option value="GA">Georgia</option>
                            <option value="HI">Hawaii</option>
                            <option value="ID">Idaho</option>
                            <option value="IL">Illinois</option>
                            <option value="IN">Indiana</option>
                            <option value="IA">Iowa</option>
                            <option value="KS">Kansas</option>
                            <option value="KY">Kentucky</option>
                            <option value="LA">Louisiana</option>
                            <option value="ME">Maine</option>
                            <option value="MD">Maryland</option>
                            <option value="MA">Massachusetts</option>
                            <option value="MI">Michigan</option>
                            <option value="MN">Minnesota</option>
                            <option value="MS">Mississippi</option>
                            <option value="MO">Missouri</option>
                            <option value="MT">Montana</option>
                            <option value="NE">Nebraska</option>
                            <option value="NV">Nevada</option>
                            <option value="NH">New Hampshire</option>
                            <option value="NJ">New Jersey</option>
                            <option value="NM">New Mexico</option>
                            <option value="NY">New York</option>
                            <option value="NC">North Carolina</option>
                            <option value="ND">North Dakota</option>
                            <option value="OH">Ohio</option>
                            <option value="OK">Oklahoma</option>
                            <option value="OR">Oregon</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="RI">Rhode Island</option>
                            <option value="SC">South Carolina</option>
                            <option value="SD">South Dakota</option>
                            <option value="TN">Tennessee</option>
                            <option value="TX">Texas</option>
                            <option value="UT">Utah</option>
                            <option value="VT">Vermont</option>
                            <option value="VA">Virginia</option>
                            <option value="WA">Washington</option>
                            <option value="WV">West Virginia</option>
                            <option value="WI">Wisconsin</option>
                            <option value="WY">Wyoming</option>
						</select>
                        <input type="hidden" value="Please insert the state of the funeral home" id="err_select_fh_State">
					</div>
					<br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->   
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Zipcode
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="number" min="10000" max="99999" class="form-control" placeholder="Zipcode" id="txtbx_edit_fh_Zip" value="<?php echo $FHZip; ?>" >	
                        <input type="hidden" value="Please insert the zipcode of the funeral home" id="err_txtbx_edit_fh_Zip">
                    </div>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
            
             <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Location of Wake
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <select required class="form-control" id="select_edit_location_Wake">
                            <?php 
							echo '<option value="';
							if($DCLocationWake == "FH"){
								echo $DCLocationWake . '" selected>Funeral Home</option>';	
							}
							else if($DCLocationWake == "CH"){
								echo $DCLocationWake . '" selected>Church</option>';	
							}
							else if($DCLocationWake == "BT"){
								echo $DCLocationWake . '" selected>Both</option>';	
							}
							?>
							<option value="" disabled>------</option>
                            <option value="FH">Funeral Home</option>
							<option value="CH">Church</option>
							<option value="BT">Both</option>
                            
						</select>
                        <input type="hidden" value="Please enter the location for the wake" id="err_select_edit_location_Wake">
                    </div>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->    
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-md-4">
                    <p class="push-left">Date of Wake(Funeral)</p>
                    <div class="push-left push-right input-group-lg">
                    	<input <?php if($DCLocationWake == "CH") echo 'disabled'; else echo 'required';?> type="date" min="<?php echo date("Y-m-d"); ?>" class="form-control" placeholder="mm/dd/yyyy" value="<?php if($DCDateWakeFH != '0000-00-00') echo $DCDateWakeFH; else echo ""; ?>" id="select_edit_date_wake_FH" name="edit_funeral_mass_wake">
                        <input type="hidden" value="Please enter the date for the wake (funeral)" id="err_select_edit_date_wake_FH">
                    </div>
                    <br>
                </div>
            	<div class="col-12 col-md-4">
                	<div class="form-group input-group-lg push-left push-right" id="time_edit_start_wake_funeral">
                    	<p>Start</p>
                        <select <?php if($DCLocationWake == "CH") echo 'disabled'; else echo 'required';?> class="form-control" id="select_edit_time_wake_start_FH" name="edit_funeral_mass_wake">
                        	<?php 
							if($DCStartTimeWakeFH != '00:00:00'){
								echo '<option selected value="' . $DCStartTimeWakeFH . '">' . date("g:i A", strtotime($DCStartTimeWakeFH)) . '</option>'; 
								echo '<option disabled value="">------</option>'; 
							}
							else{
								echo '<option selected disabled value="">------</option>'; 	
							}

							for($i = 7; $i < 23; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                        <input type="hidden" value="Please enter the start time for the wake (funeral)" id="err_select_edit_time_wake_start_FH">
                	</div>
                </div>
                <div class="col-12 col-md-4">
                	<div class="form-group input-group-lg push-left push-right">
                    	<p>End</p>
                        <select <?php if($DCLocationWake == "CH") echo 'disabled'; else echo 'required';?> class="form-control" id="select_edit_time_wake_end_FH">
                        	<?php 
							if($DCEndTimeWakeFH != '00:00:00'){
								echo '<option selected value="' . $DCEndTimeWakeFH . '">' . date("g:i A", strtotime($DCEndTimeWakeFH)) . '</option>'; 
								echo '<option disabled value="">------</option>'; 	
							}
							else{
								echo '<option selected disabled value="">------</option>'; 	
							}

							for($i = 8; $i < 24; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                        <input type="hidden" value="Please enter the end time for the wake (funeral)" id="err_select_edit_time_wake_end_FH">
                	</div>
                    <br>
                    <br>
                </div>
            </div> <!-- /row -->    
                           
             <div class="row"> <!-- row -->
                <div class="col-12 col-md-4">
                    <p class="push-left">Date of Wake(Church)</p>
                    <div class="push-left push-right input-group-lg">
                    	<input <?php if($DCLocationWake == "FH") echo 'disabled'; else echo 'required';?> type="date" min="<?php echo date("Y-m-d"); ?>" class="form-control" placeholder="mm/dd/yyyy" value="<?php if($DCDateWakeCH != '0000-00-00') echo $DCDateWakeCH; else echo ""; ?>" id="select_edit_date_wake_CH">
                        <input type="hidden" value="Please enter the date for the wake (church)" id="err_select_edit_date_wake_CH">
                    </div>
                    <br>
                </div>
            	<div class="col-12 col-md-4">
                	<div class="form-group input-group-lg push-left push-right">
                    	<p>Start</p>
                        <select <?php if($DCLocationWake == "FH") echo 'disabled'; else echo 'required';?> class="form-control" id="select_edit_time_wake_start_CH">
                        	<?php 
								if($DCStartTimeWakeCH != '00:00:00'){
									echo '<option selected value="' . $DCStartTimeWakeCH . '">' . date("g:i A", strtotime($DCStartTimeWakeCH)) . '</option>'; 
									echo '<option disabled value="">------</option>'; 	
								}
								else{
									echo '<option selected disabled value="">------</option>'; 	
								}

							for($i = 7; $i < 23; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                        <input type="hidden" value="Please enter the start time for the wake (church)" id="err_select_edit_time_wake_start_CH">
                	</div>
                </div>
                <div class="col-12 col-md-4">
                	<div class="form-group input-group-lg push-left push-right" id="time_edit_start_wake_funeral">
                    	<p>End</p>
                        <select <?php if($DCLocationWake == "FH") echo 'disabled'; else echo 'required';?> class="form-control" id="select_edit_time_wake_end_CH">
                        	<?php 
								if($DCEndTimeWakeCH != '00:00:00'){
									echo '<option selected value="' . $DCEndTimeWakeCH . '">' . date("g:i A", strtotime($DCEndTimeWakeCH)) . '</option>'; 
									echo '<option disabled value="">------</option>'; 	
								}
								else{
									echo '<option selected disabled value="">------</option>'; 	
								}

							for($i = 8; $i < 24; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                        <input type="hidden" value="Please enter the end time for the wake (church)" id="err_select_edit_time_wake_end_CH">
                	</div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>
            </div> <!-- /row -->      
            
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Mass Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row -->        
                    
             <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Mass Date
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="date" min="<?php echo date("Y-m-d"); ?>" class="form-control" placeholder="mm/dd/yyyy" value="<?php echo $DCMassDate;?>" id="date_edit_mass_Date">
                        <input type="hidden" value="Please insert the mass date" id="err_date_edit_mass_Date">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
    
            <div class="row"> <!-- row -->    
            	<div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Mass Time
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                	<div class="input-group input-group-lg">
                    	<select required id="select_edit_mass_Time" class="form-control">
                        	<?php echo '<option selected value="' . $DCMassTime . '">' . date('g:i A', strtotime($DCMassTime)) . '</option>'; ?>
                        	<option value="" disabled>------</option>
                            
                            <?php
							for($i = 7; $i < 20; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                        <input type="hidden" value="Please insert the mass time" id="err_select_edit_mass_Time">
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
                    
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Cemetery Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row -->                
                    
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Will there be a body?
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <select class="form-control" id="select_edit_deceased_Burial" required>
                        	<option value="" disabled>Select an option</option>
							<option value="1" <?php if($DCIfCemetery == "1") echo 'selected'; ?> >Yes</option>
							<option value="0" <?php if($DCIfCemetery == "0") echo 'selected'; ?>>No</option>
						</select>
                        <input type="hidden" value="Please enter if there will be a burial" id="err_select_edit_deceased_Burial">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->       
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Cemetery Notes
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <textarea rows="3" class="form-control" id="txtbx_edit_cemetery_Notes">
                        	<?php echo $DCCemetery; ?>
                        </textarea>
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                
                    
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Priest Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row --> 
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        First Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="First Name" id="txtbx_edit_Priest_FName" value="<?php echo $FMPPriestFName; ?>" >	
                        <input type="hidden" value="Please insert the priest's first name" id="err_txtbx_edit_Priest_FName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                 
                    
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Last Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Last Name" id="txtbx_edit_Priest_LName" value="<?php echo $FMPPriestLName; ?>" >	
                        <input type="hidden" value="Please insert the priest's last name" id="err_txtbx_edit_Priest_LName">
                    </div>
                     <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                   
                    
             <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
            		<h2 class="push-left push-right">Bereavement Minister Information</h2>
                    <br>
            	</div> <!-- /col-12 -->
            </div> <!-- /row --> 
            
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        First Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="First Name" id="txtbx_edit_BM_FName" value="<?php echo $FMPBMFName; ?>" >	
                        <input type="hidden" value="Please insert the bereavement first name" id="err_txtbx_edit_BM_FName">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->                 
                    
            <div class="row"> <!-- row -->
                <div class="col-12 col-sm-4 col-md-2"> <!-- col-12 col-sm-4 col-md-2 -->
                    <p class="push-left">
                        Last Name
                    </p>
                </div> <!-- /col-12 /col-sm-4 /col-md-2 -->
                <div class="col-12 col-sm-7 col-md-5"> <!-- col-12 col-sm-7 col-md-5 -->
                    <div class="input-group-lg">
                        <input required type="text" class="form-control" placeholder="Last Name" id="txtbx_edit_BM_LName" value="<?php echo $FMPBMLName; ?>" >	
                        <input type="hidden" value="Please insert the priest's last name" id="err_txtbx_edit_BM_LName">
                    </div>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-sm-7 /col-md-5 -->
            </div> <!-- /row -->
            
            <div class="row">
            	<div class="col-12">
                	<div id="edit_record_feedback">
                    
                    </div>
                </div>
            </div>
            
            <div class="row" id="edit_btns"> <!-- row -->
            	<div class="col-2 hidden-xs-down"></div>
            	<div class="col-12 col-sm-4 col-md-4">
                	<div id="edit_btn_home">
                        <a href="staff.php">
                            <button class="btn btn-lg btn-block btn-green">Home</button>
                        </a>
                    </div>
                    <br>
                    <br>
                </div>
            	<div class="col-12 col-sm-4 col-md-4">
                	<div id="edit_btn_submit">
                        <button id="btn_edit_save_changes" type="submit" class="btn btn-lg btn-block btn-green">Save Changes</button>
                    </div>
                    <br>
                    <br>
                </div>
                <div class="col-2 hidden-xs-down"></div>
            </div> <!-- /row -->
            
                 
                    <?php
                     } ?>
                    
                </div>
                
                <div id="footer">
                    <?php
                    getFooter();
                    ?>
                </div>
            </form>

	</div> <!-- /MainForm -->              
</div> <!-- /container -->
</body>
</html>	