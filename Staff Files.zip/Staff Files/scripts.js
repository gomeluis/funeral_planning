/*
  ______ .______       _______     ___   .___________. _______ 
 /      ||   _  \     |   ____|   /   \  |           ||   ____|
|  ,----'|  |_)  |    |  |__     /  ^  \ `---|  |----`|  |__   
|  |     |      /     |   __|   /  /_\  \    |  |     |   __|  
|  `----.|  |\  \----.|  |____ /  _____  \   |  |     |  |____ 
 \______|| _| `._____||_______/__/     \__\  |__|     |_______|
*/ 
															
/*=================================================
When a create record form is submitted, validate it before doing anything.
Return error messages if invalid. Insert record if valid.
==================================================*/
$(document).ready(function() {
    $("#create_New_Deceased_Record").on("submit", function(e){
		e.preventDefault();
		
		$('[name="CreatePageMainForm"] *').removeAttr('style');
		$("#btn_create_New_Deceased_Record").html("");
		$("#create_record_feedback").html("<div class='loader'></div>");

		
		var phoneCheck = /^\d{3}-\d{3}-\d{4}$/;
		var emailCheck = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		var formOk = true;
		var errMsg = '';
		
		//Search through literally every field to see what's missing
		if($("#txtbx_create_Deceased_FName").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's first name<br>";
			$("#txtbx_create_Deceased_FName").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Deceased_LName").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's last name<br>";
			$("#txtbx_create_Deceased_LName").css("border", "1px solid #FF2222");	
		}		
		if(!$("#txtbx_create_Deceased_Address").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's address<br>";
			$("#txtbx_create_Deceased_Address").css("border", "1px solid #FF2222");	
		}
		if(!$("#txtbx_create_Deceased_City").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's city<br>";
			$("#txtbx_create_Deceased_City").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_create_Deceased_State")){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's state<br>";
			$("#select_create_Deceased_State").css("border", "1px solid #FF2222");	
		}
		if(!$("#txtbx_create_Deceased_Zip")){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's zipcode<br>";
			$("#txtbx_create_Deceased_Zip").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_create_Deceased_Gender").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's gender<br>";
			$("#select_create_Deceased_Gender").css("border", "1px solid #FF2222");	
		}
		if($("#date_create_Deceased_Passing").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the deceased's passing date<br>";
			$("#date_create_Deceased_Passing").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Primary_Contact_FName").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the primary contact's first name<br>";
			$("#txtbx_create_Primary_Contact_FName").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Primary_Contact_LName").val() == ''){
			formOk = false; 

			errMsg += "<b>x</b> Error: Please enter the primary contact's last name<br>";
			$("#txtbx_create_Primary_Contact_LName").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_create_Primary_Contact_Relation").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the primary contact's relation to deceased<br>";
			$("#select_create_Primary_Contact_Relation").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Primary_Contact_Email").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the primary contact's email<br>";
			$("#txtbx_create_Primary_Contact_Email").css("border", "1px solid #FF2222");	
		}
		if(!emailCheck.test($("#txtbx_create_Primary_Contact_Email").val())){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter a valid email for primary contact<br>";
			$("#txtbx_create_Primary_Contact_Email").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Primary_Contact_Phone").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the primary contact's phone number<br>";
			$("#txtbx_create_Primary_Contact_Phone").css("border", "1px solid #FF2222");	
		}
		if(!phoneCheck.test($("#txtbx_create_Primary_Contact_Phone").val())){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter a valid phone number for primary contact<br>(xxx-xxx-xxxx)<br>";
			$("#txtbx_create_Primary_Contact_Phone").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Funeral_Home_Name").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the name of the funeral home<br>";
			$("#txtbx_create_Funeral_Home_Name").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Funeral_Home_Address").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the address of the funeral home<br>";
			$("#txtbx_create_Funeral_Home_Address").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Funeral_Home_City").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the city of the funeral home<br>";
			$("#txtbx_create_Funeral_Home_City").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_create_Funeral_Home_State").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the state of the funeral home<br>";
			$("#select_create_Funeral_Home_State").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Funeral_Home_Zip").val() == ''){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter the zipcode of the funeral home<br>";
			$("#txtbx_create_Funeral_Home_Zip").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_Location_of_Wake").val()){
			formOk = false; 
			
			errMsg += "<b>x</b> Error: Please enter a location for the wake<br>";
			$("#select_Location_of_Wake").css("border", "1px solid #FF2222");	
		}
		if($("#select_Location_of_Wake").val() == 'Funeral Home' || $("#select_Location_of_Wake").val() == 'Both'){	
			if($("#select_create_Date_Wake_FH").val() == ''){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a date for the wake (funeral home)<br>";
				$("#select_create_Date_Wake_FH").css("border", "1px solid #FF2222");	
			}
			var selectedDate = new Date($("#select_create_Date_Wake_FH").val());
			var today = new Date(getToday());
			
			if(selectedDate < today){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a wake date that wasn't before today (funeral home)<br>";
				$("#select_create_Date_Wake_FH").css("border", "1px solid #FF2222");
			}
		
			if(!$("#select_create_Time_Wake_Start_FH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a start time for the wake (funeral home)<br>";
				$("#select_create_Time_Wake_Start_FH").css("border", "1px solid #FF2222");	
			}
			if(!$("#select_create_Time_Wake_End_FH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter an ending time for the wake (funeral home)<br>";
				$("#select_create_Time_Wake_End_FH").css("border", "1px solid #FF2222");	
			}
			if($("#select_create_Time_Wake_End_FH").val() <= $("#select_create_Time_Wake_Start_FH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (funeral home)<br>";
				$("#select_create_Time_Wake_End_FH").css("border", "1px solid #FF2222");
				$("#select_create_Time_Wake_Start_FH").css("border", "1px solid #FF2222");
			}
		}
		if($("#select_Location_of_Wake").val() == 'CH' || $("#select_Location_of_Wake").val() == 'BT'){	
			if(!$("#select_create_Date_Wake_CH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a date for the wake (church)<br>";
				$("#select_create_Date_Wake_CH").css("border", "1px solid #FF2222");	
			}
			var selectedDate = new Date($("#select_create_Date_Wake_CH").val());
			var today = new Date(getToday());
			
			if(selectedDate < today){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a date that wasn't before today (church)<br>";
				$("#select_create_Date_Wake_CH").css("border", "1px solid #FF2222");
			}
		
			if(!$("#select_create_Time_Wake_Start_CH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter a start time for the wake (church)<br>";
				$("#select_create_Time_Wake_Start_CH").css("border", "1px solid #FF2222");	
			}
			if(!$("#select_create_Time_Wake_End_CH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Please enter an ending time for the wake (church)<br>";
				$("#select_create_Time_Wake_End_CH").css("border", "1px solid #FF2222");	
			}
			if($("#select_create_Time_Wake_End_CH").val() <= $("#select_create_Time_Wake_Start_CH").val()){
				formOk = false; 
				
				errMsg += "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (church)<br>";
				$("#select_create_Time_Wake_End_CH").css("border", "1px solid #FF2222");
				$("#select_create_Time_Wake_Start_CH").css("border", "1px solid #FF2222");
			}
		}
		if($("#date_create_Mass_Date").val() == ''){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter a date for the mass<br>";
			$("#date_create_Mass_Date").css("border", "1px solid #FF2222");	
		}
		var selectedDate = new Date($("#select_create_Mass_Date").val());
		var today = new Date(getToday());
			
		if(selectedDate < today){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter a mass date that wasn't before today<br>";
			$("#date_create_Mass_Date").css("border", "1px solid #FF2222");
		}
		if(!$("#select_create_Mass_Time").val()){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter a mass time<br>";
			$("#select_create_Mass_Time").css("border", "1px solid #FF2222");	
		}
		if(!$("#select_create_Body").val()){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Pleas insert if there will be a burial<br>";
			$("#select_create_Body").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Priest_FName").val() == ''){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter the priest's first name<br>";
			$("#txtbx_create_Priest_FName").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_Priest_LName").val() == ''){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter the priest's last name<br>";
			$("#txtbx_create_Priest_LName").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_BM_FName").val() == ''){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter the bereavement minister's first name<br>";
			$("#txtbx_create_BM_FName").css("border", "1px solid #FF2222");	
		}
		if($("#txtbx_create_BM_LName").val() == ''){
			formOk = false; 
				
			errMsg += "<b>x</b> Error: Please enter the bereavement minister's last name<br>";
			$("#txtbx_create_BM_LName").css("border", "1px solid #FF2222");	
		}
				

		if(formOk == false){
			$("#create_record_feedback").html("<div class='alert alert-danger' role='alert'>" + errMsg + "</div>");
			$("#btn_create_New_Deceased_Record").html("<input type='submit' class='btn btn-lg btn-block btn-green' value='Create Record'>");
		}
		else{
			var data = {
				"deceased_FName": $("#txtbx_create_Deceased_FName").val(),
				"deceased_LName": $("#txtbx_create_Deceased_LName").val(),
				"deceased_Address": $("#txtbx_create_Deceased_Address").val(),
				"deceased_City": $("#txtbx_create_Deceased_City").val(),
				"deceased_State": $("#select_create_Deceased_State").val(),
				"deceased_Zip": $("#txtbx_create_Deceased_Zip").val(),
				"deceased_Gender": $("#select_create_Deceased_Gender").val(),
				"deceased_Passing": $("#date_create_Deceased_Passing").val(),
				"contact_FName": $("#txtbx_create_Primary_Contact_FName").val(),
				"contact_LName": $("#txtbx_create_Primary_Contact_LName").val(),
				"contact_Relation": $("#select_create_Primary_Contact_Relation").val(),
				"contact_Email": $("#txtbx_create_Primary_Contact_Email").val(),
				"contact_Phone": $("#txtbx_create_Primary_Contact_Phone").val(),
				"funeral_Home_Name": $("#txtbx_create_Funeral_Home_Name").val(),
				"funeral_Home_Address": $("#txtbx_create_Funeral_Home_Address").val(),
				"funeral_Home_City": $("#txtbx_create_Funeral_Home_City").val(),
				"funeral_Home_State": $("#select_create_Funeral_Home_State").val(),
				"funeral_Home_Zip": $("#txtbx_create_Funeral_Home_Zip").val(),
				"wake_Location": $("#select_Location_of_Wake").val(),
				"mass_Date": $("#date_create_Mass_Date").val(),
				"mass_Time": $("#select_create_Mass_Time").val(),
				"body_Burial": $("#select_create_Body").val(),
				"cemetery_Notes": $("#txtbx_create_Cemetery_Notes").val(),
				"priest_FName": $("#txtbx_create_Priest_FName").val(),
				"priest_LName": $("#txtbx_create_Priest_LName").val(),
				"bereavement_FName": $("#txtbx_create_BM_FName").val(),
				"bereavement_LName": $("#txtbx_create_BM_LName").val()
			}
			
			if(data.wake_Location == 'FH' || data.wake_Location == 'BT'){
				data.date_Wake_FH = $("#select_create_Date_Wake_FH").val();
				data.time_Wake_Start_FH = $("#select_create_Time_Wake_Start_FH").val();
				data.time_Wake_End_FH = $("#select_create_Time_Wake_End_FH").val();
			}
			if(data.wake_Location == 'CH' || data.wake_Location == 'BT'){
				data.date_Wake_CH = $("#select_create_Date_Wake_CH").val();
				data.time_Wake_Start_CH = $("#select_create_Time_Wake_Start_CH").val();
				data.time_Wake_End_CH = $("#select_create_Time_Wake_End_CH").val();
			}
			
			$.ajax({
				type: "POST",
				url: "insertNewRecord.php",
				data: data,
				success: function(result) {
					if(result[0] == 1){
						$("#create_record_feedback").html("<div class='alert alert-success' role='alert'><p>You've successfully submitted a deceased record</p><br><p>You can view the new record, return to home, or submit a new record</p></div>");
						$("#btn_create_New_Deceased_Record").html("<a href='staff.php'><button class='btn btn-block btn-lg btn-green'>Home</button><br></a><a href='showRecord.php?st=dec&dec=" + result[1] + "'><button type='button' class='btn btn-lg btn-block btn-green'>View Record</button></a><br><a href='create.php'><button type='button' class='btn btn-lg btn-block btn-green'>Start a New Record</button>");
					}
					else{
						for(var i = 0; i < result[1].length; i++){
							$("#" + result[1][i]).css("border", "1px solid #FF2222");	
						}
						
						$("#create_record_feedback").html("<div class='alert alert-danger' role='alert'>" + result[2] + "</div>");
						$("#btn_create_New_Deceased_Record").html("<input type='submit' class='btn btn-lg btn-block btn-green' value='Create Record'>");
					}
					console.log(result);
				},
				error: function(xhr){
					$("#create_record_feedback").html("<div class='alert alert-danger' role='alert'>" + xhr.message + "</div>");
					$("#btn_create_New_Deceased_Record").html("<input type='submit' class='btn btn-lg btn-block btn-green' value='Create Record'>");					
				},
				dataType: "json"
			});
		}
	});
});

/*=================================================
Generate the location of wake select options,
location will either be the funeral home, church, or both 
==================================================*/
$(document).ready(function(){
	$("#select_Location_of_Wake").on("change", function(){
		var today = getToday();
		var wakeLocationFuneral = '';
		var wakeLocationChurch = '';
		
		wakeLocationFuneral = '<div class="col-12 col-md-4"><h5 class="push-left">Date of Wake(Funeral)</h5><div class="push-left push-right form-group input-group-lg"><input type="date" min="' + today + '" class="form-control" placeholder="mm/dd/yyyy" id="select_create_Date_Wake_FH" required></div><br></div><div class="col-12 col-md-4"><div class="form-group input-group-lg push-left push-right" id="time_start_wake_funeral"><h5>Start</h5><select class="form-control" required id="select_create_Time_Wake_Start_FH"><option disabled selected value="">Select an option</option>';
					
		for(var i = 7; i < 21; i++){
			wakeLocationFuneral += getTimeOption(i);
		}
					
		wakeLocationFuneral += '</select></div></div><div class="col-12 col-md-4"><div class="form-group input-group-lg push-left push-right" id="time_end_wake_funeral"><h5>End</h5><select class="form-control" required id="select_create_Time_Wake_End_FH"><option disabled selected value="">Select an option</option>';
					
		for(var i = 8; i < 22; i++){
			wakeLocationFuneral += getTimeOption(i);
		}
		
		wakeLocationFuneral += '</select></div></div>';
		
		wakeLocationChurch = '<div class="col-12 col-md-4"><h5 class="push-left">Date of Wake(Church)</h5><div class="push-left push-right form-group input-group-lg"><input type="date" min="' + today + '" class="form-control" placeholder="mm/dd/yyyy" id="select_create_Date_Wake_CH" required></div><br></div><div class="col-12 col-md-4"><div class="form-group input-group-lg push-left push-right" id="time_start_wake_church"><h5>Start</h5><select required class="form-control"  id="select_create_Time_Wake_Start_CH"><option disabled selected value="">Select an option</option>';
					
		for(var i = 7; i < 21; i++){
			wakeLocationChurch += getTimeOption(i);
		}
					
		wakeLocationChurch += '</select></div></div><div class="col-12 col-md-4"><div class="form-group input-group-lg push-left push-right" id="time_end_wake_church"><h5>End</h5><select class="form-control" required id="select_create_Time_Wake_End_CH"><option disabled selected value="">Select an option</option>';
					
		for(var i = 8; i < 22; i++){
			wakeLocationChurch += getTimeOption(i);
		}

		
		wakeLocationChurch += '</select></div></div>';	
		console.log("aaaa");
		
		if( $('#select_Location_of_Wake').val() == 'FH'){
			$('#wake_location').html(wakeLocationFuneral);		
		}
		else if( $('#select_Location_of_Wake').val() == 'CH'){
			$('#wake_location').html(wakeLocationChurch);
		}
		else{
			$('#wake_location').html(wakeLocationFuneral + wakeLocationChurch);		
		}		
	});
});

/*=================================================
Return today's date in the following format:
yyyy-mm-dd
==================================================*/
function getToday(){
	var today = new Date();
	
	var dd = today.getDate();	
	var mm = today.getMonth() + 1;
	var yyyy = today.getFullYear();
	
	//If the current day or month is less than 10, then add a leading 0 so restricted input date works properly
	if(parseInt(dd, 10) < 10){
		dd = '0' + dd;	
	}
	if(parseInt(mm, 10) < 10){
		mm = '0' + mm;	
	}
	
	return yyyy + '-' + mm + '-' + dd;
}

/*=================================================
Return time in option for select dropdown in the following format
E.x for 11:00 AM: <option value="11:00:00">11 AM</option>
==================================================*/
function getTimeOption(time){
	timeOption = '';
	
	if(time < 10){
		timeOption += '<option value="0' + time;	
	}
	else{
		timeOption += '<option value="' + time;	
	}
		
	timeOption += ':00:00">';	
			
	if(time < 13){
		if(time != 12){
			timeOption += time + ':00 AM</option>';	
		}
		else{
			timeOption += time + ':00 PM</option>';	
		}
	}
	else{
		timeOption += (time - 12) + ':00 PM</option>';	
	}
			
	return timeOption;
}



/*
 _______  _______   __  .___________.   .______       _______   ______   ______   .______       _______  
|   ____||       \ |  | |           |   |   _  \     |   ____| /      | /  __  \  |   _  \     |       \ 
|  |__   |  .--.  ||  | `---|  |----`   |  |_)  |    |  |__   |  ,----'|  |  |  | |  |_)  |    |  .--.  |
|   __|  |  |  |  ||  |     |  |        |      /     |   __|  |  |     |  |  |  | |      /     |  |  |  |
|  |____ |  '--'  ||  |     |  |        |  |\  \----.|  |____ |  `----.|  `--'  | |  |\  \----.|  '--'  |
|_______||_______/ |__|     |__|        | _| `._____||_______| \______| \______/  | _| `._____||_______/ 
                                                                                                         
*/
/*=================================================
Based on the selected location of the wake, disable 
either the funeral home, church, or none of them.
==================================================*/
$(document).ready(function(){
	$("#select_edit_location_Wake").on("change", function(){
		var location = $("#select_edit_location_Wake").val();
		
		if(location == "FH"){
			$("select_edit_date_wake_FH").prop("required", true);
			$("#select_edit_date_wake_FH").removeAttr("disabled");
			
			$("#select_edit_time_wake_start_FH").prop("required", true);
			$("#select_edit_time_wake_start_FH").removeAttr("disabled");
			
			$("#select_edit_time_wake_end_FH").prop("required", true);
			$("#select_edit_time_wake_end_FH").removeAttr("disabled");
			
			$("#select_edit_date_wake_CH").prop("disabled", true);
			$("#select_edit_date_wake_CH").removeAttr("required");
			
			$("#select_edit_time_wake_start_CH").prop("disabled", true);
			$("#select_edit_time_wake_start_CH").removeAttr("required");
			
			$("#select_edit_time_wake_end_CH").prop("disabled", true);
			$("#select_edit_time_wake_end_CH").removeAttr("required");
		}
		else if(location == "CH"){
			$("#select_edit_date_wake_CH").prop("required", true);
			$("#select_edit_date_wake_CH").removeAttr("disabled");
			
			$("#select_edit_time_wake_start_CH").prop("required", true);
			$("#select_edit_time_wake_start_CH").removeAttr("disabled");
			
			$("#select_edit_time_wake_end_CH").prop("required", true);
			$("#select_edit_time_wake_end_CH").removeAttr("disabled");
			
			$("#select_edit_date_wake_FH").prop("disabled", true);
			$("#select_edit_date_wake_FH").removeAttr("required");
			
			$("#select_edit_time_wake_start_FH").prop("disabled", true);
			$("#select_edit_time_wake_start_FH").removeAttr("required");
			
			$("#select_edit_time_wake_end_FH").prop("disabled", true);
			$("#select_edit_time_wake_end_FH").removeAttr("required");
		}
		else if(location == "BT"){
			$("#select_edit_date_wake_FH").prop("required", true);
			$("#select_edit_time_wake_start_FH").prop("required", true);
			$("#select_edit_time_wake_end_FH").prop("required", true);
			
			$("#select_edit_date_wake_CH").prop("required", true);
			$("#select_edit_time_wake_start_CH").prop("required", true);
			$("#select_edit_time_wake_end_CH").prop("required", true);
			
			$("#select_edit_date_wake_FH").removeAttr("disabled");
			$("#select_edit_time_wake_start_FH").removeAttr("disabled");
			$("#select_edit_time_wake_end_FH").removeAttr("disabled");
			
			$("#select_edit_date_wake_CH").removeAttr("disabled");
			$("#select_edit_time_wake_start_CH").removeAttr("disabled");
			$("#select_edit_time_wake_end_CH").removeAttr("disabled");
		}
	});
});

$(document).ready(function(){
	$("#edit_Deceased_Record_Form").on("submit", function(e){
		e.preventDefault();
		
		$('[name="EditPageMainForm"] *').removeAttr('style');
		$("#edit_btn_home").html("");
		$("#edit_btn_submit").html("");
		$("#edit_record_feedback").html("<div class='loader'></div>");
		
		var editedIds = [];	
		var phoneCheck = /^\d{3}-\d{3}-\d{4}$/;
		var emailCheck = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		formOk = true;
		
		//Get all the id's the user will potentially edit and check if they are invalid
		$("#edit_Deceased_Record_Form :input").not('[type="hidden"]').not('button').not('[disabled]').not('textarea').each(function(){
			editedIds.push($(this).attr("id"));
		});
		
		var errMsg = '';
		
		for(var i = 0; i < editedIds.length; i++){
			if($("#" + editedIds[i]).val() == ''){
				errMsg += "<b>x</b> Error: " + $("#err_" + editedIds[i]).val() + "<br>";
				$("#" + editedIds[i]).css("border", "1px solid #FF2222");
				formOk = false;
			}
		}
		
		if(!emailCheck.test($("#txtbx_edit_contact_Email").val())){
			formOk = false; 
					
			errMsg += "<b>x</b> Error: Please enter a valid email for primary contact<br>";
			$("#txtbx_edit_contact_Phone").css("border", "1px solid #FF2222");	
		}
		
		if(!phoneCheck.test($("#txtbx_edit_contact_Phone").val())){
			formOk = false; 
						
			errMsg += "<b>x</b> Error: Please enter a valid phone number for primary contact<br>(xxx-xxx-xxxx)<br>";
			$("#txtbx_edit_contact_Email").css("border", "1px solid #FF2222");	
		}
		
		if($("#select_edit_location_Wake").val() == 'CH' || $("#select_edit_location_Wake").val() == 'BT'){	

			if($("#select_edit_time_wake_end_CH").val() <= $("#select_edit_time_wake_start_CH").val()){
				formOk = false; 
							
				errMsg += "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (church)<br>";
				$("#select_edit_time_wake_end_CH").css("border", "1px solid #FF2222");
				$("#select_edit_time_wake_start_CH").css("border", "1px solid #FF2222");
			}
		
			var selectedDate = new Date($("#select_edit_date_wake_CH").val());
			var today = new Date(getToday());
						
			if(selectedDate < today){
				formOk = false; 
							
				errMsg += "<b>x</b> Error: Please enter a date that wasn't before today (church)<br>";
				$("#select_edit_date_wake_CH").css("border", "1px solid #FF2222");
			}
		}
		
		if($("#select_edit_location_Wake").val() == 'FH' || $("#select_edit_location_Wake").val() == 'BT'){	

			if($("#select_edit_time_wake_end_FH").val() <= $("#select_edit_time_wake_start_FH").val()){
				formOk = false; 
							
				errMsg += "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (funeral home)<br>";
				$("#select_edit_time_wake_end_FH").css("border", "1px solid #FF2222");
				$("#select_edit_time_wake_start_FH").css("border", "1px solid #FF2222");
			}
		
			var selectedDate = new Date($("#select_edit_date_wake_FH").val());
			var today = new Date(getToday());
						
			if(selectedDate < today){
				formOk = false; 
							
				errMsg += "<b>x</b> Error: Please enter a date that wasn't before today (funeral home)<br>";
				$("#select_edit_date_wake_FH").css("border", "1px solid #FF2222");
			}
		}
		
		var selectedDate = new Date($("#date_edit_mass_Date").val());
		var today = new Date(getToday());
					
		if(selectedDate < today){
			formOk = false; 
						
			errMsg += "<b>x</b> Error: Please enter a mass date that wasn't before today<br>";
			$("#date_edit_mass_Date").css("border", "1px solid #FF2222");
		}
		
		if(!formOk){
			$("#edit_record_feedback").html("<div class='push-left push-right'><div class='alert alert-danger' role='alert'>" + errMsg + "</div></div>");
			$("#edit_btn_home").html('<a href="staff.php"><button class="btn btn-lg btn-block btn-green">Home</button></a>');	
			$("#edit_btn_submit").html('<button id="btn_edit_save_changes" type="submit" class="btn btn-lg btn-block btn-green">Save Changes</button>');	
		}
		else{
			var data = {
				"dec": 
					{
						value: getSearchType("dec"),
						id: "hide_dec"
					},
				"deceased_FName": 
					{ 
						value: $("#txtbx_edit_deceased_FName").val(), 
					   	id:"#txtbx_edit_deceased_FName"
					},
				"deceased_LName": 
					{
						value:$("#txtbx_edit_deceased_LName").val(), 
						id: "#txtbx_edit_deceased_LName"
					},
				"deceased_Address": 
					{
						value: $("#txtbx_edit_deceased_Address").val(), 
						id: "#txtbx_edit_deceased_Address"
					},
				"deceased_City": 
					{
						value: $("#txtbx_edit_deceased_City").val(), 
						id: "#txtbx_edit_deceased_City"
					},
				"deceased_State": 
					{
						value: $("#select_edit_deceased_State").val(), 
						id: "#select_edit_deceased_State"
					},
				"deceased_Zip": 
					{
						value: $("#txtbx_edit_deceased_Zip").val(), 
						id: "#txtbx_edit_deceased_Zip"
					},
				"deceased_Gender": 
					{
						value: $("#select_edit_deceased_Gender").val(), 
						id: "#select_edit_deceased_Gender"
					},
				"deceased_Passing": 
					{
						value: $("#date_edit_deceased_Passing").val(), 
						id: "#date_edit_deceased_Passing"
					},
				"contact_FName": 
					{
						value: $("#txtbx_edit_contact_FName").val(), 
						id: "#txtbx_edit_contact_FName"
					},
				"contact_LName": 
					{
						value: $("#txtbx_edit_contact_LName").val(), 
						id: "#txtbx_edit_contact_LName"
					},
				"contact_Relation":
					{
						value: $("#select_edit_contact_Relation").val(), 
						id: "#select_edit_contact_Relation"
					},
				"contact_Email": 
					{
						value: $("#txtbx_edit_contact_Email").val(), 
						id: "#txtbx_edit_contact_Email"
					},
				"contact_Phone": 
					{
						value: $("#txtbx_edit_contact_Phone").val(), 
						id: "#txtbx_edit_contact_Phone"
					},
				"funeral_Home_Name": 
					{
						value: $("#txtbx_edit_fh_Name").val(), 
						id: "#txtbx_edit_fh_Name"
					},
				"funeral_Home_Address": 
					{ 
						value: $("#txtbx_edit_fh_Address").val(), 
						id: "#txtbx_edit_fh_Address"
					},
				"funeral_Home_City": 
					{ 
						value: $("#txtbx_edit_fh_City").val(), 
						id: "#txtbx_edit_fh_City"
					},
				"funeral_Home_State": 
					{
						value: $("#select_edit_fh_State").val(), 
						id: "#select_edit_fh_State"
					},
				"funeral_Home_Zip": 
					{
						value: $("#txtbx_edit_fh_Zip").val(), 
						id: "#txtbx_edit_fh_Zip"
					},
				"wake_Location": 
					{
						value: $("#select_edit_location_Wake").val(), 
						id: "#select_edit_location_Wake"
					},
				"wake_fh_date": 
					{
						value: $("#select_edit_date_wake_FH").val(), 
						id: "#select_edit_date_wake_FH"
					},
				"wake_fh_start": 
					{
						value: $("#select_edit_time_wake_start_FH").val(), 
						id: "#select_edit_time_wake_start_FH"
					},
				"wake_fh_end": 
					{
						value: $("#select_edit_time_wake_end_FH").val(), 
						id: "#select_edit_time_wake_end_FH"
					},
				"wake_ch_date": 
					{
						value: $("#select_edit_date_wake_CH").val(), 
						id: "#select_edit_date_wake_CH"
					},
				"wake_ch_start": 
					{
						value: $("#select_edit_time_wake_start_CH").val(), 
						id: "#select_edit_time_wake_start_CH"
					},
				"wake_ch_end": 
					{
						value: $("#select_edit_time_wake_end_CH").val(), 
						id: "#select_edit_time_wake_end_CH"
					},
				"mass_Date": 
					{
						value: $("#date_edit_mass_Date").val(), 
						id: "#date_edit_mass_Date"
					},
				"mass_Time": 
					{
						value: $("#select_edit_mass_Time").val(), 
						id: "#select_edit_mass_Time"
					},
				"body_Burial": 
					{
						value: $("#select_edit_deceased_Burial").val(), 
						id: "#select_edit_deceased_Burial"
					},
				"cemetery_Notes": 
					{
						value: $("#txtbx_edit_cemetery_Notes").val(), 
						id: "#txtbx_edit_cemetery_Notes"
					},
				"priest_FName": 
					{
						value: $("#txtbx_edit_Priest_FName").val(), 
						id: "#txtbx_edit_Priest_FName"
					},
				"priest_LName": 
					{
						value: $("#txtbx_edit_Priest_LName").val(), 
						id: "#txtbx_edit_Priest_LName"
					},
				"bereavement_FName": 
					{
						value: $("#txtbx_edit_BM_FName").val(), 
						id: "#txtbx_edit_BM_FName"
					},
				"bereavement_LName": 
					{
						value: $("#txtbx_edit_BM_LName").val(), 
						id: "#txtbx_edit_BM_LName"
					}
			}
			
			console.log(data);
			
			$.ajax({
				type: "POST",
				url: "editRecord.php",
				dataType: "json",
				data: data,
				success: function(result) {
					console.log(result);
					
					if(result[0] == 1){
						$("#edit_record_feedback").html("<div class='push-left push-right'><div class='alert alert-success' role='alert'><p>You've successfully edited this deceased record</p><br><p>You can return to home, view the record or start a new record</p></div></div>");
						
						$("#edit_btns").html("<div class='col-12 col-md-4'><div class='push-left'><a href='staff.php'><button class='btn btn-block btn-lg btn-green'>Home</button><br></a></div></div><div class='col-12 col-md-4'><a href='showRecord.php?st=dec&dec=" + getSearchType("dec") + "'><button type='button' class='btn btn-lg btn-block btn-green'>View Record</button></a><br></div><div class='col-12 col-md-4'><div class='push-right'><a href='create.php'><button type='button' class='btn btn-lg btn-block btn-green'>Start a New Record</button></div></div>");
					}
					else{
						for(var i = 0; i < result[1].length; i++){
							$(result[1][i]).css("border", "1px solid #FF2222");	
							
							if(result[1][i].substr(0, 1) == '#'){
								errMsg += '<b>x</b> Error: ' + $(result[1][i]).val() + '<br>';
							}
							else{
								errMsg += result[1][i];
							}
						}
						
						$("#edit_record_feedback").html("<div class='push-left push-right'><div class='alert alert-danger' role='alert'>" + errMsg + "</div></div>");
						$("#edit_btn_home").html('<a href="staff.php"><button class="btn btn-lg btn-block btn-green">Home</button></a>');	
						$("#edit_btn_submit").html('<button id="btn_edit_save_changes" type="submit" class="btn btn-lg btn-block btn-green">Save Changes</button>');
					}
				},
				error: function(xhr){
					console.log(xhr.responseText);
					$("#edit_record_feedback").html("<div class='push-left push-right'><div class='alert alert-danger' role='alert'>" + errMsg + "</div></div>");
					$("#edit_btn_home").html('<a href="staff.php"><button class="btn btn-lg btn-block btn-green">Home</button></a>');	
					$("#edit_btn_submit").html('<button id="btn_edit_save_changes" type="submit" class="btn btn-lg btn-block btn-green">Save Changes</button>');					
				},
			});
		}
	});
});


/*
     _______. _______     ___      .______        ______  __    __     .______       _______   ______   ______   .______       _______       _______.
    /       ||   ____|   /   \     |   _  \      /      ||  |  |  |    |   _  \     |   ____| /      | /  __  \  |   _  \     |       \     /       |
   |   (----`|  |__     /  ^  \    |  |_)  |    |  ,----'|  |__|  |    |  |_)  |    |  |__   |  ,----'|  |  |  | |  |_)  |    |  .--.  |   |   (----`
    \   \    |   __|   /  /_\  \   |      /     |  |     |   __   |    |      /     |   __|  |  |     |  |  |  | |      /     |  |  |  |    \   \    
.----)   |   |  |____ /  _____  \  |  |\  \----.|  `----.|  |  |  |    |  |\  \----.|  |____ |  `----.|  `--'  | |  |\  \----.|  '--'  |.----)   |   
|_______/    |_______/__/     \__\ | _| `._____| \______||__|  |__|    | _| `._____||_______| \______| \______/  | _| `._____||_______/ |_______/    
                                                                                                                                                                                                                                                                                                          
*/
/*=================================================
Display textboxes based on the select option the 
user selects in the search page.
==================================================*/
$(document).ready(function() {
	$("#select_deceased_search_type").on("change", function(){
		
		if( $("#select_deceased_search_type").val() == "name" ){
			
			$("#first_search_type").html('<br><div class="input-group input-group-lg"><input type="text" class="form-control" placeholder="First Name" name="txtbx_search_deceased_first_name" id="txtbx_search_deceased_first_name"></div>');
			
			$("#second_search_type").html('<br><div class="input-group input-group-lg"><input type="text" class="form-control" placeholder="Last Name" name="txtbx_search_deceased_last_name" id="txtbx_search_deceased_last_name"></div>');
		}
		else if( $("#select_deceased_search_type").val() == "date" ){
			
			$("#first_search_type").html('<h5>Start Date</h5><div class="form-group input-group-lg"><input type="date" class="form-control" name="txtbx_search_deceased_start_date" id="txtbx_search_deceased_start_date"></div>');
			
			$("#second_search_type").html('<h5>End Date</h5><div class="form-group input-group-lg"><input type="date" class="form-control" name="txtbx_search_deceased_end_date" id="txtbx_search_deceased_end_date"></div>');
		}
		
		$('#btn_search_deceased').removeAttr("style");
	});
});

/*=================================================
AJAX: Send post data and send the search by, the first 
and second search criteria and the search type for the search page.
==================================================*/
$(document).ready(function() {
	$("#btn_search_deceased").click(function(){
		if( $("#select_deceased_search_type").val() == "name" ){
			
			var data = {
				"search_by": $("#select_deceased_search_type").val(),
				"first_search": $("#txtbx_search_deceased_first_name").val(),
				"second_search": $("#txtbx_search_deceased_last_name").val()
			}	
		}
		else if( $("#select_deceased_search_type").val() == "date" ){
			
			var data = {
				"search_by": $("#select_deceased_search_type").val(),
				"first_search": $("#txtbx_search_deceased_start_date").val(),
				"second_search": $("#txtbx_search_deceased_end_date").val()
			}
		}

		data.search_type = getSearchType("st");
		
		$.ajax({
			type: "POST",
			url: "getRecords.php",
			data: data,
			success: function(data) {
				$("#searched_records").html(data);
			},
			error: function(xhr){
            	console.log("An error occured: " + xhr.status + " " + xhr.statusText);
			}
		});
	});
});

/*=================================================
Get the search type, for the search page, from the URL
==================================================*/
function getSearchType(search_type){
	var URL = window.location.search.substring(1);
    var variables = URL.split('&');
    for (var i = 0; i < variables.length; i++)
    {
        var parameter = variables[i].split('=');
        if (parameter[0] == search_type)
        {
            return decodeURIComponent(parameter[1]);
        }
    }
}

/*
 _______  _______   __  .___________.    _______   _______   ______  _______     ___           _______. _______  _______  
|   ____||       \ |  | |           |   |       \ |   ____| /      ||   ____|   /   \         /       ||   ____||       \ 
|  |__   |  .--.  ||  | `---|  |----`   |  .--.  ||  |__   |  ,----'|  |__     /  ^  \       |   (----`|  |__   |  .--.  |
|   __|  |  |  |  ||  |     |  |        |  |  |  ||   __|  |  |     |   __|   /  /_\  \       \   \    |   __|  |  |  |  |
|  |____ |  '--'  ||  |     |  |        |  '--'  ||  |____ |  `----.|  |____ /  _____  \  .----)   |   |  |____ |  '--'  |
|_______||_______/ |__|     |__|        |_______/ |_______| \______||_______/__/     \__\ |_______/    |_______||_______/ 
*/
 /*=================================================
Check if every needed field has an input and make an AJAX call
to edit a certain record.
==================================================*/
$(document).ready(function(){
	
});