<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">

<!-- Bootstrap links -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<!-- End Bootstrap links -->

<!-- FontAwesome JS links -->
<script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
<!-- End FontAwesome JS links -->

<!-- Custom style links -->
<link rel="stylesheet" type="text/css" href="Styles/styles.css" />
<!-- End custom style links -->

<!-- jQuery links -->
<script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<!-- End jQuery links -->

<!-- Google Font links -->
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- End Google Font links -->

<!-- Custom javascript links -->
<script src="Js/scripts.js"></script>

<title>Form Name</title> <!-- Change later -->
</head>
<body>

<div class="container"> <!-- container -->
	<form method="post" id="create_New_Deceased_Record">
		<div class="row"> <!-- row -->
			<div class="col-12"> <!-- col-12 -->
				<div class="w-100" id="divLogoHeader">
					<img class="img-fluid" src="images/logo-church-header.png" alt="Saint Juliana Parish" id="imgLogoHeader">
				</div>
			</div> <!-- /col-12 -->

			<div class="col-12">
				<nav class="navbar navbar-toggleable-md navbar-inverse bg-faded nav-green">
					<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
						<div class="navbar-nav">
							<a class="nav-item nav-link" href="#">
                            	<i class="fas fa-plus-square"></i> Create Record
                            </a>
                        </div>
                        <div class="navbar-nav">
							<a class="nav-item nav-link active" href="searchRecord.php?st=dec">
                            	<i class="fas fa-address-book"></i> Search Deceased Record
                            </a>
                        </div>
                        <div class="navbar-nav">
							<a class="nav-item nav-link active" href="searchRecord.php?st=fmp">
                            	<i class="fas fa-book"></i> Search Mass Plan
                            </a>
						</div>
					</div>
                    <a class="navbar-brand navbar-right" href="#">Welcome: 'Staff Member'</a>
				</nav>
			</div>
		</div> <!-- /row -->
		
		<div id="MainForm" name="CreatePageMainForm">
			<div class="row"> <!-- row -->
				<div class="col-12"  id="deceasedColHeader"> <!-- col-12 -->
					<br>
					<h2 class="text-center">Deceased Information</h2>
					<br>
				</div> <!-- /col-12 -->		
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Name</h5>
				</div> <!-- /col-12 -->	
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-left">
						<input type="text" class="form-control" placeholder="First Name" id="txtbx_create_Deceased_FName" required>	
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-right">
						<input type="text" class="form-control" placeholder="Last Name" id="txtbx_create_Deceased_LName" required>
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Address</h5>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<div class="input-group input-group-lg push-right push-left">
						<input required type="text" class="form-control" placeholder="Address" id="txtbx_create_Deceased_Address">
					</div>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-sm-4 -->
					<div class="input-group input-group-lg push-left">
						<input required type="text" class="form-control" placeholder="City" id="txtbx_create_Deceased_City">
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-4 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-sm-4 -->
					<div class="input-group input-group-lg">
						<select required class="form-control" id="select_create_Deceased_State">
							<option value="" disabled selected>Select an option</option>
							<option value="AL">Alabama</option>
                            <option value="AK">Alaska</option>
                            <option value="AZ">Arizona</option>
                            <option value="AR">Arkansas</option>
                            <option value="CA">California</option>
                            <option value="CO">Colorado</option>
                            <option value="CT">Connecticut</option>
                            <option value="DE">Delaware</option>
                            <option value="DC">District Of Columbia</option>
                            <option value="FL">Florida</option>
                            <option value="GA">Georgia</option>
                            <option value="HI">Hawaii</option>
                            <option value="ID">Idaho</option>
                            <option value="IL">Illinois</option>
                            <option value="IN">Indiana</option>
                            <option value="IA">Iowa</option>
                            <option value="KS">Kansas</option>
                            <option value="KY">Kentucky</option>
                            <option value="LA">Louisiana</option>
                            <option value="ME">Maine</option>
                            <option value="MD">Maryland</option>
                            <option value="MA">Massachusetts</option>
                            <option value="MI">Michigan</option>
                            <option value="MN">Minnesota</option>
                            <option value="MS">Mississippi</option>
                            <option value="MO">Missouri</option>
                            <option value="MT">Montana</option>
                            <option value="NE">Nebraska</option>
                            <option value="NV">Nevada</option>
                            <option value="NH">New Hampshire</option>
                            <option value="NJ">New Jersey</option>
                            <option value="NM">New Mexico</option>
                            <option value="NY">New York</option>
                            <option value="NC">North Carolina</option>
                            <option value="ND">North Dakota</option>
                            <option value="OH">Ohio</option>
                            <option value="OK">Oklahoma</option>
                            <option value="OR">Oregon</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="RI">Rhode Island</option>
                            <option value="SC">South Carolina</option>
                            <option value="SD">South Dakota</option>
                            <option value="TN">Tennessee</option>
                            <option value="TX">Texas</option>
                            <option value="UT">Utah</option>
                            <option value="VT">Vermont</option>
                            <option value="VA">Virginia</option>
                            <option value="WA">Washington</option>
                            <option value="WV">West Virginia</option>
                            <option value="WI">Wisconsin</option>
                            <option value="WY">Wyoming</option>
						</select>
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-4 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-sm-4 -->
					<div class="input-group input-group-lg push-right">
						<input required type="text" class="form-control" placeholder="Zipcode" id="txtbx_create_Deceased_Zip">
					</div>
					<br>
					<br>
				</div> <!-- /col-12 /col-msm-4 -->
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Gender</h5>
				</div> <!-- /col-12 -->	
				<div class="col-12 col-sm-6 col-md-4"> <!-- col-12 col-sm-6 col-md-4 -->
					<div class="input-group input-group-lg push-left">
						<select class="form-control" id="select_create_Deceased_Gender" required>
                        	<option value="" selected disabled>Select an option</option>
							<option value="M">Male</option>
							<option value="F">Female</option>
						</select>
					</div>
					<br>
					<br>
				</div><!-- /col-12 /col-sm-6 /col-md-4 -->		
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Date of Passing</h5>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-6 col-md-4"> <!-- col-12 col-sm-6 col-md-4 -->
					<div class="form-group input-group-lg push-left">
						<input required type="date" class="form-control" placeholder="mm/dd/yyyy" id="date_create_Deceased_Passing">
					</div>
					<br>
					<br>
                    <br>
                    <br>
				</div> <!-- /col-12 /col-sm-6 /col-md-4 -->	
			</div> <!-- /row -->
			
			<div class="row"> <!-- row -->
				<div class="col-12"> <!-- col-12 -->
					<h2 class="text-center">Primary Contact Information</h2>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12">
					<h5 class="push-left">Contact's Name and Relation</h5>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-left">
						<input required type="text" class="form-control" placeholder="First Name" id="txtbx_create_Primary_Contact_FName">	
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-right">
						<input required type="text" class="form-control" placeholder="Last Name" id="txtbx_create_Primary_Contact_LName">
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 col-md-4 -->
					<div class="input-group input-group-lg push-left">
						<select required class="form-control" id="select_create_Primary_Contact_Relation">
                        	<option value="" selected disabled>Select an option</option>
							<option value="spouse">Spouse</option>
							<option value="son">Son</option>
							<option value="daughter">Daughter</option>
							<option value="grandson">Grandson</option>
							<option value="grandaughter">Grandaughter</option>
							<option value="father">Father</option>
                            <option value="mother">Mother</option>
							<option value="grandfather">Grandfather</option>
                            <option value="grandmother">Grandmother</option>
                            <option value="brother">Brother</option>
							<option value="sister">Sister</option>
							<option value="other">Other</option>
						</select>
					</div>
					<br>
					<br>
				</div> <!-- /col-12 /col-sm-6 /col-md-4 -->
            </div>
            <div class="row"> <!-- row -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-md-6 -->
                	<h5 class="push-left">Contact's Email</h5>
					<div class="input-group input-group-lg push-left">
						<input required type="email" class="form-control" id="txtbx_create_Primary_Contact_Email" placeholder="Email">
					</div>
					<br>
                </div> <!-- /col-12 /col-md-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-md-6 -->
                	<h5 class="push-right">Contact's Phone</h5>
					<div class="input-group input-group-lg push-right">
						<input required type="tel" class="form-control" id="txtbx_create_Primary_Contact_Phone" placeholder="Ex: 123-456-7890">
					</div>
					<br>
					<br>
					<br>
                    <br>
				</div> <!-- /col-12 /col-md-6 -->	
			</div> <!-- /row -->			
				
			<div class="row"> <!-- row -->
				<div class="col-12"> <!-- col-12 -->
					<h2 class="text-center">Funeral and Wake Information</h2>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Name of Funeral Home and Address</h5>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<div class="input-group input-group-lg push-left push-right">
						<input required type="text" class="form-control" id="txtbx_create_Funeral_Home_Name" placeholder="Name">
					</div>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<div class="input-group input-group-lg push-right push-left">
						<input required type="text" class="form-control" placeholder="Address" id="txtbx_create_Funeral_Home_Address">
					</div>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-ms-4 -->
					<div class="input-group input-group-lg push-left">
						<input required type="text" class="form-control" placeholder="City" id="txtbx_create_Funeral_Home_City">
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-4 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-sm-4 -->
					<div class="input-group input-group-lg">
						<select required class="form-control" id="select_create_Funeral_Home_State" name="wumbo">
							<option value="" disabled selected>Select an option</option>
							<option value="AL">Alabama</option>
                            <option value="AK">Alaska</option>
                            <option value="AZ">Arizona</option>
                            <option value="AR">Arkansas</option>
                            <option value="CA">California</option>
                            <option value="CO">Colorado</option>
                            <option value="CT">Connecticut</option>
                            <option value="DE">Delaware</option>
                            <option value="DC">District Of Columbia</option>
                            <option value="FL">Florida</option>
                            <option value="GA">Georgia</option>
                            <option value="HI">Hawaii</option>
                            <option value="ID">Idaho</option>
                            <option value="IL">Illinois</option>
                            <option value="IN">Indiana</option>
                            <option value="IA">Iowa</option>
                            <option value="KS">Kansas</option>
                            <option value="KY">Kentucky</option>
                            <option value="LA">Louisiana</option>
                            <option value="ME">Maine</option>
                            <option value="MD">Maryland</option>
                            <option value="MA">Massachusetts</option>
                            <option value="MI">Michigan</option>
                            <option value="MN">Minnesota</option>
                            <option value="MS">Mississippi</option>
                            <option value="MO">Missouri</option>
                            <option value="MT">Montana</option>
                            <option value="NE">Nebraska</option>
                            <option value="NV">Nevada</option>
                            <option value="NH">New Hampshire</option>
                            <option value="NJ">New Jersey</option>
                            <option value="NM">New Mexico</option>
                            <option value="NY">New York</option>
                            <option value="NC">North Carolina</option>
                            <option value="ND">North Dakota</option>
                            <option value="OH">Ohio</option>
                            <option value="OK">Oklahoma</option>
                            <option value="OR">Oregon</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="RI">Rhode Island</option>
                            <option value="SC">South Carolina</option>
                            <option value="SD">South Dakota</option>
                            <option value="TN">Tennessee</option>
                            <option value="TX">Texas</option>
                            <option value="UT">Utah</option>
                            <option value="VT">Vermont</option>
                            <option value="VA">Virginia</option>
                            <option value="WA">Washington</option>
                            <option value="WV">West Virginia</option>
                            <option value="WI">Wisconsin</option>
                            <option value="WY">Wyoming</option>
						</select>
					</div>
					<br>
				</div> <!-- /col-12 /col-sm-4 -->
				<div class="col-12 col-sm-4"> <!-- col-12 col-sm-4 -->
					<div class="input-group input-group-lg push-right">
						<input required type="text" class="form-control" placeholder="Zipcode" id="txtbx_create_Funeral_Home_Zip">
					</div>
					<br>
					<br>
				</div> <!-- /col-12 /col-msm-4 -->
			</div> <!-- /row -->
				
			<div class="row"> <!-- row -->
				<div class="col-12 col-sm-12 col-md-4"> <!-- col-12 col-md-4 -->
					<h5 class="push-left push-right">Location of Wake</h5>
					<div class="input-group input-group-lg push-left">
						<select required class="form-control" name="select_Location_of_Wake" id="select_Location_of_Wake">
							<option value="" selected disabled>Select an option</option>
                            
							<option value="FH">Funeral Home</option>
							<option value="CH">Church</option>
							<option value="BT">Both</option>
						</select>
					</div>
					<br>
                    <br>
				</div> <!-- /col-12 /col-md-4 -->
			</div> <!-- /row -->
			
			<div class="row" id="wake_location"> <!-- row -->
				
			</div> <!-- /row -->
            
            <br>
            <br>
            <div class="row"> <!-- row -->
            	<div class="col-12"> <!-- col-12 -->
                	<h2 class="text-center">Mass Information</h2>
                    <br>
                </div> <!-- /col-12 -->
                <div class="col-12 col-md-6"> <!-- col-12 col-md-6 -->
                    <h5 class="push-left">Date of Mass</h5>
                    <div class="form-group input-group-lg push-left push-right">
                        <input required min="<?php echo date("Y-m-d"); ?>" type="date" class="form-control" id="date_create_Mass_Date">
                    </div>
                    <br>
                </div> <!-- /col-12 /col-md-6 -->
                <div class="col-12 col-md-6"> <!-- col-12 col-md-6 -->
                    <h5 class="push-right push-left">Time of Mass</h5>
                	<div class="input-group input-group-lg push-right push-left">
                    	<select required id="select_create_Mass_Time" class="form-control">
                        	<option value="" selected disabled>Select a time</option>
                            
                            <?php
							for($i = 7; $i < 20; $i++){
								if($i < 13){
									if($i == 12){
										echo '<option value="12:00:00">12:00 PM</option>';	
									}
									else if($i < 10){
										echo '<option value="0' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
									else{
										echo '<option value="' . $i . ':00:00">' . $i . ':00 AM</option>';
									}
								}
								else{
									echo '<option value="' . $i . ':00:00">' . ($i - 12) . ':00 PM</option>';
								}
							}
							?>
                        </select>
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                </div> <!-- /col-12 /col-md-6 -->
            </div> <!-- /row -->
            
            <div class="row"> <!-- row -->
				<div class="col-12"> <!-- col-12 -->
					<br>
					<h2 class="text-center" id="deceasedHeader">Cemetery Information</h2>
					<br>
				</div> <!-- /col-12 -->		
				<div class="col-12 col-sm-6 col-md-4"> <!-- col-12 col-sm-6 col-md-4 -->
					<h5 class="push-left">Will There Be a Body?</h5>
					<div class="input-group input-group-lg push-left">
						<select required class="form-control" id="select_create_Body">
							<option value="" selected disabled>Select an option</option>
							<option value="1">Yes</option>
							<option value="0">No</option>
						</select>
					</div>
					<br>
				</div> <!-- col-12 col-sm-6 col-md-4 -->							
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Cemetery Notes</h5>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<div class="form-group push-left push-right">
    					<textarea class="form-control" id="txtbx_create_Cemetery_Notes" rows="3"></textarea>
  					</div>
  				<br>
  				<br>
                <br>
                <br>
				</div> <!-- /col-12 -->	
            </div> <!-- /row -->
			
			<div class="row"> <!-- row -->
				<div class="col-12"> <!-- col-12 -->
					<h2 class="text-center">Priest and Bereavement Minister</h2>
					<br>
				</div> <!-- /col-12 -->
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Priest Name</h5>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-left">
						<input required type="text" class="form-control" placeholder="First Name" id="txtbx_create_Priest_FName">	
					</div>
				<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-right">
						<input required type="text" class="form-control" placeholder="Last Name" id="txtbx_create_Priest_LName">
					</div>
				<br>
				<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12"> <!-- col-12 -->
					<h5 class="push-left">Bereavement Minister Name</h5>
				</div> <!-- /col-12 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-left">
						<input required type="text" class="form-control" placeholder="First Name" id="txtbx_create_BM_FName">	
					</div>
				<br>
				</div> <!-- /col-12 /col-sm-6 -->
				<div class="col-12 col-sm-6"> <!-- col-12 col-sm-6 -->
					<div class="input-group input-group-lg push-right">
						<input required type="text" class="form-control" placeholder="Last Name" id="txtbx_create_BM_LName">
					</div>
				<br>
				<br>
				</div> <!-- /col-12 /col-sm-6 -->
			</div> <!-- /row -->
            
            <div class="row">
            	<div class="col-12">
                	<div id="create_record_feedback" class="push-left push-right">
                    	
                    </div>
                </div>
            </div>
			
			<div class="row"> <!-- row -->
				<div class="col-sm-2 col-md-3 hidden-xs-down"></div>
				<div class="col-12 col-sm-8 col-md-6"> <!-- col-12 col-sm-6 col-md-4 -->
                   <div id="btn_create_New_Deceased_Record">
                    	<input type="submit" class="btn btn-lg btn-block btn-green" value="Create Record">
					</div>
                    <br>
				</div> <!-- /col-12 /col-sm-6 /col-md-4 -->
				<div class="col-sm-2 col-md-3 hidden-xs-down"></div>
			</div> <!-- /row -->
            
            <div id="footer">
				<?php
                include "functions.php";
                getFooter();
                ?>
            </div>
			
		</div> <!-- /MainForm -->           
	</form>   
</div> <!-- /container -->
</body>
</html>	






