CHANGES:

- create.php
Added some additional <divs> to be able to give feedback to the user regarding if a record was successfully created

- functions.php
Added some additional functions to go along with new staff files, most notably the get deceasedRecord and gerMassPlan functions

- scripts.js
Added new AJAX calls to search, create, and update deceased records. Added some smaller functions

- Styles.css
Added some additional styles for new staff pages



NEW STUFF:

- editDeceasedRecord.php
The HTML page that the user sees to edit a deceased record.

- editRecord.php
An AJAX page that saves changes a user makes to a deceased records

- searchRecord.php
The HTML page the user sees to search either a deceased record, or a mass plan

- getRecords.php
An AJAX call to get a list of records based on the search criteria the user input

- showRecord.php
The HTML page where the user can view a specified record

- insertNewRecord.php
An AJAX call to create a new deceased record

- staff.php
A simple home screen for the staff