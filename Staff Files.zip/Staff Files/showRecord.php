<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">

<!-- Bootstrap links -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<!-- End Bootstrap links -->

<!-- FontAwesome JS links -->
<script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
<!-- End FontAwesome JS links -->

<!-- Custom style links -->
<link rel="stylesheet" type="text/css" href="Styles/styles.css" />
<!-- End custom style links -->

<!-- jQuery links -->
<script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<!-- End jQuery links -->

<!-- Google Font links -->
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- End Google Font links -->

<!-- Custom javascript links -->
<script src="Js/scripts.js"></script>

<title>Found Record</title>
</head>
<body>

<div class="container"> <!-- container -->
	<div class="row"> <!-- row -->
		<div class="col-12"> <!-- col-12 -->
			<div class="w-100" id="divLogoHeader">
				<img class="img-fluid" src="images/logo-church-header.png" alt="Saint Juliana Parish" id="imgLogoHeader">
			</div>
		</div> <!-- /col-12 -->

		<div class="col-12">
			<nav class="navbar navbar-toggleable-md navbar-inverse bg-faded nav-green">
				<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a class="navbar-brand" href="#">Welcome: 'Staff Member'</a>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav">
						<a class="nav-item nav-link" href="create.php">Create Record <span class="sr-only">(current)</span></a>
						<a class="nav-item nav-link" href="searchRecord.php?st=dec">Search Deceased Record</a>
						<a class="nav-item nav-link" href="searchRecord.php?st=fmp">Search Mass Plan</a>
					</div>
				</div>
			</nav>
		</div>
	</div> <!-- /row -->
		
	<div id="MainForm"> <!-- MainForm -->
		<div class="row" id="deceasedColHeader"></div>

	<?php
	
	include "functions.php";

	$conn = connectDB();
	mysql_select_db('dbfuneral', $conn);
	
	$deceasedID = $_REQUEST['dec'];
	$searchType = $_REQUEST['st'];
	
	if($searchType == "dec"){
		getDeceasedRecord($deceasedID);
	}
	else if($searchType == "fmp"){
		getMassPlanRecord($deceasedID);	
	}

	?>
		
	<div id="footer">
       	<?php
       	getFooter();
		?>
    </div>
    
    
	</div><!-- /MainForm -->
</div> <!-- /container -->
</body>
</html>
		
		
		
		