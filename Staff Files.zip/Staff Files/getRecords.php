<?php 

include "functions.php";

$conn = connectDB();

mysql_select_db('dbfuneral', $conn);

$records = '';

$query = "SELECT DC.int_deceased_ID AS ID, CONCAT(DC.vchar_dec_First_Name, ' ', DC.vchar_dec_Last_Name) AS FullName, DC.vchar_dec_Street_Address AS Address, DC.vchar_dec_City AS City, DC.char_dec_State AS State, DC.vchar_dec_Zipcode AS Zip, DC.dt_date_Of_Death AS PassingDate FROM Deceased AS DC";

if($_REQUEST['search_by'] == 'name') {
	
	if($_REQUEST['first_search'] == '' && $_REQUEST['second_search'] == ''){
			
		$query .= "";
	}
	else if($_REQUEST['first_search'] == ''){
		
		$query .= " WHERE DC.vchar_dec_Last_Name ='" . $_REQUEST['second_search'] . "'";
	}
	else if($_REQUEST['second_search'] == ''){
		
		$query .= " WHERE DC.vchar_dec_First_Name='" . $_REQUEST['first_search'] . "'";	
	}
	else{
		$query .= " WHERE DC.vchar_dec_First_Name='" . $_REQUEST['first_search'] . "' AND DC.vchar_dec_Last_Name ='" . $_REQUEST['second_search'] . "'";
	}
}
else if($_REQUEST['search_by'] == 'date') {
	
	$query .= " WHERE DC.dt_date_Of_Wake_FH BETWEEN '" . $_REQUEST['first_search'] . "' AND '" . $_REQUEST['second_search'] . "'";
}
else{
	
	$query = '';
}

$result = mysql_query($query) or die(mysql_error());

$records ='
	<div class="row hidden-xs-down">
		<div class="col-12">
			<div class="container">
				<div class="row">
					<div class="col-2">
						<p><strong>Name</strong></p>
					</div>
					<div class="col-2">
						<p><strong>Address</strong></p>
					</div>
					<div class="col-2">
						<p><strong>City</strong></p>
					</div>
					<div class="col-1">
						<p><strong>State</strong></p>
					</div>
					<div class="col-1">
						<p><strong>Zip</strong></p>
					</div>
					<div class="col-2">
						<p><strong>Passing Date</strong></p>
					</div>
				</div>
			</div>
		</div>
	</div>';

$counter = 0;

$numRows = mysql_num_rows($result);

//Check if there's any rows returned by the query
if($numRows > 0){
	
	$counter = 1;

	while ($row = mysql_fetch_array($result)) {
		
		//Use this to format the passing date as m/dd/yyyy
		$passingDate = strtotime($row['PassingDate']);
		$passingDate = date('n/d/Y', $passingDate);
		
		//For every other record, make the background color a gray color to distinguish records, and for aesthetic (this is only for a mobile view)				
		if($counter % 2 == 0){
			$records .= '<div class="row" name="deceasedRecordRowM">';
		}
		else{
			$records .= '<div class="row">';	
		}
			
		$records .='<div class="col-12"><div class="container">';
			
			//For every other record, make the background color a gray color to distinguish records, and for aesthetic
			if($counter % 2 == 0){
				$records .= '<div class="row" name="deceasedRecordRow">';	
			}
			else{
				$records .= '<div class="row">';
			}			
					$records .= '<div class="col-12"><br></div>
							<div class="col-3 hidden-sm-up">
								<p><strong>Name: </strong></p>
							</div>
							<div class="col-9 col-sm-2">
								<p>' . $row["FullName"] . '</p>
							</div>
							<div class="col-3 hidden-sm-up">
								<p><strong>Address: </strong></p>
							</div>
							<div class="col-9 col-sm-2">'
								. $row["Address"] .
							'</div>
							<div class="col-3 hidden-sm-up">
								<p><strong>City: </strong></p>
							</div>
							<div class="col-9 col-sm-2">'
								. $row["City"] .
							'</div>
							<div class="col-3 hidden-sm-up">
								<p><strong>State: </strong></p>
							</div>
							<div class="col-9 col-sm-1">'
								. $row["State"] .
							'</div>
							<div class="col-3 hidden-sm-up">
								<p><strong>Zip: </strong></p>
							</div>
							<div class="col-9 col-sm-1">'
								. $row["Zip"] .
							'</div>
							<div class="col-3 hidden-sm-up">
								<p><strong>Passing Date: </strong></p>
							</div>
							<div class="col-9 col-sm-2">'
								. $passingDate .
							'</div>
							<div class="col-12 col-sm-2">
								<div>';
		
		//Change the search link based on the current page
		if($_REQUEST['search_type'] == 'dec'){
			$records .= '<a href="showRecord.php?st=dec&dec=' . $row["ID"] . '">';
		}
		else if($_REQUEST['search_type'] == 'fmp'){
			$records .= '<a href="showRecord.php?st=fmp&dec=' . $row["ID"] . '">';
		}
								$records .=
										'	<button type="button" class="btn btn-lg btn-block btn-green">View</button>
									</a>
								</div>
								<br>
							</div>
						</div>
					</div>
				</div>
			</div>';
			
		$counter += 1;
	}
}
else{

	$records = '<h5 class="text-center">No results found</h5><br><br>';	
}

closeDB($conn);
	
echo $records;


?>