<?php

include 'functions.php';
$conn = connectDB();

mysql_select_db('dbfuneral', $conn);

$deceased_FName = $_REQUEST['deceased_FName'];
$deceased_LName = $_REQUEST['deceased_LName'];
$deceased_Address = $_REQUEST['deceased_Address'];
$deceased_City = $_REQUEST['deceased_City'];
$deceased_State = $_REQUEST['deceased_State'];
$deceased_Zip = $_REQUEST['deceased_Zip'];
$deceased_Gender = $_REQUEST['deceased_Gender'];
$deceased_Passing = $_REQUEST['deceased_Passing'];
$contact_FName = $_REQUEST['contact_FName'];
$contact_LName = $_REQUEST['contact_LName'];
$contact_Relation = $_REQUEST['contact_Relation'];
$contact_Email = $_REQUEST['contact_Email'];
$contact_Phone = $_REQUEST['contact_Phone'];
$funeral_Home_Name = $_REQUEST['funeral_Home_Name'];
$funeral_Home_Address = $_REQUEST['funeral_Home_Address'];
$funeral_Home_City = $_REQUEST['funeral_Home_City'];
$funeral_Home_State = $_REQUEST['funeral_Home_State'];
$funeral_Home_Zip = $_REQUEST['funeral_Home_Zip'];
$wake_Location = $_REQUEST['wake_Location'];
$mass_Date = $_REQUEST['mass_Date'];
$mass_Time = $_REQUEST['mass_Time'];
$body_Burial = $_REQUEST['body_Burial'];
$cemetery_Notes = $_REQUEST['cemetery_Notes'];
$priest_FName = $_REQUEST['priest_FName'];
$priest_LName = $_REQUEST['priest_LName'];
$bereavement_FName = $_REQUEST['bereavement_FName'];
$bereavement_LName = $_REQUEST['bereavement_LName'];

$date_Wake_FH = $_REQUEST['date_Wake_FH'];		
$time_Wake_Start_FH = $_REQUEST['time_Wake_Start_FH'];
$time_Wake_End_FH = $_REQUEST['time_Wake_End_FH'];

$date_Wake_CH = $_REQUEST['date_Wake_CH'];		
$time_Wake_Start_CH = $_REQUEST['time_Wake_Start_CH'];
$time_Wake_End_CH = $_REQUEST['time_Wake_End_CH'];

$formOk = true;
$data = array();
$data[0] = 1;
$data[1] = array();

if($deceased_FName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Deceased_FName");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's first name<br>";
}
if($deceased_LName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Deceased_LName");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's last name<br>";
}
if($deceased_Address == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Deceased_Address");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's address<br>";
}
if($deceased_City == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Deceased_City");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's city<br>";
}
if($deceased_State == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Deceased_State");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's state<br>";
}
if($deceased_Zip == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Deceased_Zip");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's zipcode<br>";
}
if($deceased_Gender == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Deceased_Gender");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's gender<br>";
}
if($deceased_Passing == ''){
	$formOk = false;
	
	array_push($data[1], "date_create_Deceased_Passing");
	$data[2] .= "<b>x</b> Error: Please enter the deceased's passing date<br>";
}
if($contact_FName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_FName");
	$data[2] .= "<b>x</b> Error: Please enter the primary contact's first name<br>";
}
if($contact_LName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_LName");
	$data[2] .= "<b>x</b> Error: Please enter the primary contact's last name<br>";
}
if($contact_Relation == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Primary_Contact_Relation");
	$data[2] .= "<b>x</b> Error: Please enter the primary contact's relation to deceased<br>";
} 
if($contact_Email == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_Email");
	$data[2] .= "<b>x</b> Error: Please enter the primary contact's email<br>";
} 
if (!filter_var($contact_Email, FILTER_VALIDATE_EMAIL)) {
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_Email");
	$data[2] .= "<b>x</b> Error: Please enter a valid email for primary contact<br>";
}
if($contact_Phone == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_Phone");
	$data[2] .= "<b>x</b> Error: Please enter the primary contact's phone number<br>";
} 
if(!preg_match("/^\d{3}-\d{3}-\d{4}$/", $contact_Phone)){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Primary_Contact_Phone");
	$data[2] .= "<b>x</b> Error: Please enter a valid phone number for primary contact<br>(xxx-xxx-xxxx)<br>";
} 
if($funeral_Home_Name == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Funeral_Home_Name");
	$data[2] .= "<b>x</b> Error: Please enter the name of the funeral home<br>";
} 
if($funeral_Home_Address == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Funeral_Home_Address");
	$data[2] .= "<b>x</b> Error: Please enter the address of the funeral home<br>";
} 
if($funeral_Home_City == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Funeral_Home_City");
	$data[2] .= "<b>x</b> Error: Please enter the city of the funeral home<br>";
} 
if($funeral_Home_State == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Funeral_Home_State");
	$data[2] .= "<b>x</b> Error: Please enter the state of the funeral home<br>";
} 
if($funeral_Home_Zip == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Funeral_Home_Zip");
	$data[2] .= "<b>x</b> Error: Please enter the zipcode of the funeral home<br>";
} 
if($wake_Location == ''){
	$formOk = false;
	
	array_push($data[1], "select_Location_of_Wake");
	$data[2] .= "<b>x</b> Error: Please enter a location for the wake<br>";
} 
if($wake_Location == 'FH' || $wake_Location == 'BT'){
	if($date_Wake_FH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Date_Wake_FH");
		$data[2] .= "<b>x</b> Error: Please enter a date for the wake (funeral home)<br>";
	}
	
	$today = date("Y-m-d");
	$selectedDate = date("Y-m-d", strtotime($date_Wake_FH));
	
	if($selectedDate < $today){
		$formOk = false;
		
		array_push($data[1], "select_create_Date_Wake_FH");
		$data[2] .= "<b>x</b> Error: Please enter a wake date that wasn't before today (funeral home)<br>";
	}
	if($time_Wake_Start_FH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_Start_FH");
		$data[2] .= "<b>x</b> Error: Please enter a start time for the wake (funeral home)<br>";
	}
	if($time_Wake_End_FH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_End_FH");
		$data[2] .= "<b>x</b> Error: Please enter an ending time for the wake (funeral home)<br>";
	}
	if(strtotime($time_Wake_End_FH) <= strtotime($time_Wake_Start_FH)){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_End_FH", "select_create_Time_Wake_Start_FH");
		$data[2] .= "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (funeral home)<br>";
	}
}
if($wake_Location == 'Church' || $wake_Location == 'Both'){
	if($date_Wake_CH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Date_Wake_CH");
		$data[2] .= "<b>x</b> Error: Please enter a date for the wake (church)<br>";
	}
	
	$today = date("Y-m-d");
	$selectedDate = date("Y-m-d", strtotime($date_Wake_CH));
	
	if($selectedDate < $today){
		$formOk = false;
		
		array_push($data[1], "select_create_Date_Wake_CH");
		$data[2] .= "<b>x</b> Error: Please enter a wake date that wasn't before today (church)<br>";
	}
	if($time_Wake_Start_CH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_Start_CH");
		$data[2] .= "<b>x</b> Error: Please enter a start time for the wake (church)<br>";
	}
	if($time_Wake_End_CH == ''){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_End_CH");
		$data[2] .= "<b>x</b> Error: Please enter an ending time for the wake (church)<br>";
	}
	if(strtotime($time_Wake_End_CH) <= strtotime($time_Wake_Start_CH)){
		$formOk = false;
		
		array_push($data[1], "select_create_Time_Wake_End_CH", "select_create_Time_Wake_Start_CH");
		$data[2] .= "<b>x</b> Error: Your ending wake time cannot be earlier than your start time (church)<br>";
	}
}
if($mass_Date == ''){
	$formOk = false;
	
	array_push($data[1], "date_create_Mass_Date");
	$data[2] .= "<b>x</b> Error: Please enter a date for the mass<br>";
} 

$today = date("Y-m-d");
$selectedDate = date("Y-m-d", strtotime($mass_Date));

if($selectedDate < $today){
	$formOk = false;
	
	array_push($data[1], "date_create_Mass_Date");
	$data[2] .= "<b>x</b> Error: Please enter a mass date that wasn't before today<br>";
}
if($mass_Time == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Mass_Time");
	$data[2] .= "<b>x</b> Error: Please enter a mass time<br>";
} 
if($body_Burial == ''){
	$formOk = false;
	
	array_push($data[1], "select_create_Body");
	$data[2] .= "<b>x</b> Error: Pleas insert if there will be a burial<br>";
}
if($priest_FName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Priest_FName");
	$data[2] .= "<b>x</b> Error: Please enter the priest's first name<br>";
}
if($priest_LName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_Priest_LName");
	$data[2] .= "<b>x</b> Error: Please enter the priest's last name<br>";
}
if($bereavement_FName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_BM_FName");
	$data[2] .= "<b>x</b> Error: Please enter the bereavement minister's first name<br>";
}
if($bereavement_LName == ''){
	$formOk = false;
	
	array_push($data[1], "txtbx_create_BM_LName");
	$data[2] .= "<b>x</b> Error: Please enter the bereavement minister's last name<br>";
}

if($formOk){
	
	if($wake_Location == 'Funeral Home'){
		$wake_Location = 'FH';
	}
	elseif($wake_Location == 'Church'){
		$wake_Location = 'CH';
	}
	elseif($wake_Location == 'Both'){
		$wake_Location = 'BT';
	}
	
	$insertDeceased = "
		INSERT INTO Deceased
			(vchar_dec_First_Name
			,vchar_dec_Last_Name
			,vchar_dec_Street_Address
			,vchar_dec_City
			,char_dec_State
			,vchar_dec_Zipcode
			,char_gender
			,dt_date_Of_Death
			,char_location
			,dt_date_Of_Wake_FH
			,time_start_Of_Wake_FH
			,time_end_Of_Wake_FH
			,dt_date_Of_Wake_CH
			,time_start_Of_Wake_CH
			,time_end_Of_Wake_CH
			,dt_date_Of_Mass
			,time_start_Of_Mass
			,boolean_if_Cemetery
			,longtext_cemetery_Text)
		VALUES
			('" . $deceased_FName . "'
			,'" . $deceased_LName . "'
			,'" . $deceased_Address . "'
			,'" . $deceased_City . "'
			,'" . $deceased_State . "'
			,'" . $deceased_Zip . "'
			,'" . $deceased_Gender . "'
			,'" . $deceased_Passing . "'
			,'" . $wake_Location . "'
			,'" . $date_Wake_FH . "'
			,'" . $time_Wake_Start_FH . "'
			,'" . $time_Wake_End_FH ."'
			,'" . $date_Wake_CH . "'
			,'" . $time_Wake_Start_CH . "'
			,'" . $time_Wake_End_CH . "'
			,'" . $mass_Date . "'
			,'" . $mass_Time . "'
			,'" . $body_Burial . "'
			,'" . $cemetery_Notes . "')";
	
	$deceasedResult = mysql_query($insertDeceased);
	
	if($deceasedResult){
		$deceasedID = mysql_insert_id();
		$password = uniqid();
		
		$insertPrimaryContact = "
			INSERT INTO Primary_Contact
				(vchar_primCont_First_Name
				,vchar_primCont_Last_Name
				,char_relation_To_Deceased
				,nvarchar_primCont_Email
				,vchar_primCont_Phone_Num
				,int_access_Level_ID
				,vchar_primCont_password
				,int_Deceased_ID)
			VALUES
				('" . $contact_FName . "'
				,'" . $contact_LName . "'
				,'" . $contact_Relation . "'
				,'" . $contact_Email . "'
				,'" . $contact_Phone . "'
				,'" . '2' . "'
				,'" . $password . "'
				,'" . $deceasedID . "')";
		
		$contactResult = mysql_query($insertPrimaryContact);
		
		if(!$contactResult){
			$data[0] = -1;
			$data[2] = '<b>x</b> ' . mysql_error() . '<br>';
		}

		$insertFuneralHome = "
			INSERT INTO Funeral_Home
				(vchar_funeral_Home_Name
				,vchar_FH_Address
				,vchar_FH_City
				,vchar_FH_State
				,vchar_FH_Zipcode
				,int_Deceased_ID)
			VALUES
				('" . $funeral_Home_Name . "'
				,'" . $funeral_Home_Address . "'
				,'" . $funeral_Home_City . "'
				,'" . $funeral_Home_State . "'
				,'" . $funeral_Home_Zip . "'
				,'" . $deceasedID . "')";
		
		$funeralHomeResult = mysql_query($insertFuneralHome);
		
		if(!$funeralHomeResult){
			$data[0] = -1;
			$data[2] = '<b>x</b> ' . mysql_error() . '<br>';
		}
		
		
		
		$insertPriestBMNames = "
			INSERT INTO Funeral_Mass_Plan
				(vchar_Priest_First_Name
				,vchar_Priest_Last_Name
				,vchar_BM_First_Name
				,vchar_BM_Last_Name
				,int_Deceased_ID)
			VALUES
				('" . $priest_FName . "'
				,'" . $priest_LName . "'
				,'" . $bereavement_FName . "'
				,'" . $bereavement_LName . "'
				,'" . $deceasedID . "')";
		
		$priestBMResult = mysql_query($insertPriestBMNames);
		
		if(!$priestBMResult){
			$data[0] = -1;
			$data[2] = '<b>x</b> ' . mysql_error() . '<br>';
		}
		
		if($data[0] == 1){
			$data[1] = $deceasedID;	
			
			array_push($data, $_POST);
			
			
		}
	}
	else{
		$data[0] = -1;
		$data[2] = '<b>x</b> ' . mysql_error() . '<br>';
	}
}
else{
	$data[0] = -1;
}

closeDB($conn);

echo json_encode($data);
?>