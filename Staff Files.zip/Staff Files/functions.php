<?php 
/*====================================================================
Return the full length of an entered state
====================================================================*/
function getFullState($state){
	switch($state){
		case 'AL':
			return 'Alabama';
			break;	
		case 'AK':
			return 'Alaska';
			break;
		case 'AZ':
			return 'Arizona';
			break;
		case 'AR':
			return 'Arkansas';
			break;
		case 'CA':
			return 'California';
			break;
		case 'CO':
			return 'Colorado';
			break;
		case 'CT':
			return 'Connecticut';
			break;
		case 'DE':
			return 'Delaware';
			break;
		case 'DC':
			return 'District Of Columbia';
			break;
		case 'FL':
			return 'Florida';
			break;
		case 'GA':
			return 'Georgia';
			break;
		case 'HI':
			return 'Hawaii';
			break;
		case 'ID':
			return 'Idaho';
			break;
		case 'IL':
			return 'Illinois';
			break;
		case 'IN':
			return 'India';
			break;
		case 'IA':
			return 'Iowa';
			break;
		case 'KS':
			return 'Kansas';
			break;
		case 'KY':
			return 'Kentucky';
			break;
		case 'LA':
			return 'Louisiana';
			break;
		case 'ME':
			return 'Maine';
			break;
		case 'MD':
			return 'Maryland';
			break;
		case 'MA':
			return 'Massachusetts';
			break;
		case 'MI':
			return 'Michigan';
			break;
		case 'MN':
			return 'Minnesota';
			break;
		case 'MS':
			return 'Mississippi';
			break;
		case 'MO':
			return 'Missouri';
			break;
		case 'MT':
			return 'Montana';
			break;
		case 'NE':
			return 'Nebraska';
			break;
		case 'NV':
			return 'Nevada';
			break;
		case 'NH':
			return 'New Hampshire';
			break;
		case 'NJ':
			return 'New Jersey';
			break;
		case 'NM':
			return 'New Mexico';
			break;
		case 'NY':
			return 'New York';
			break;
		case 'NC':
			return 'North Carolina';
			break;
		case 'ND':
			return 'North Dakota';
			break;
		case 'OH':
			return 'Ohio';
			break;
		case 'OK':
			return 'Oklahoma';
			break;
		case 'OR':
			return 'Oregon';
			break;
		case 'PA':
			return 'Pennsylvania';
			break;
		case 'RI':
			return 'Rhode Island';
			break;
		case 'SC':
			return 'South Carolina';
			break;
		case 'SD':
			return 'South Dakota';
			break;
		case 'TN':
			return 'Tennessee';
			break;
		case 'TX':
			return 'Texas';
			break;
		case 'UT':
			return 'Utah';
			break;
		case 'VT':
			return 'Vermont';
			break;
		case 'VA':
			return 'Virginia';
			break;
		case 'WA':
			return 'Washington';
			break;
		case 'WV':
			return 'West Virginia';
			break;
		case 'WI':
			return 'Wisconsin';
			break;
		case 'WY':
			return 'Wyoming';
			break;
		default:
			return 'Illinois';
			break;
	}
}



/*
 _______       ___   .___________.    ___      .______        ___           _______. _______ 
|       \     /   \  |           |   /   \     |   _  \      /   \         /       ||   ____|
|  .--.  |   /  ^  \ `---|  |----`  /  ^  \    |  |_)  |    /  ^  \       |   (----`|  |__   
|  |  |  |  /  /_\  \    |  |      /  /_\  \   |   _  <    /  /_\  \       \   \    |   __|  
|  '--'  | /  _____  \   |  |     /  _____  \  |  |_)  |  /  _____  \  .----)   |   |  |____ 
|_______/ /__/     \__\  |__|    /__/     \__\ |______/  /__/     \__\ |_______/    |_______|
                                                                                             
*/
/*===================================================================
Connect to the database
====================================================================*/
function connectDB(){
	
	$server = "funeralinstance.cfg8tyxsms9d.us-east-2.rds.amazonaws.com";
    $username = "funeral";
    $password = "admin123";
    $dbname = 'dbfuneral';
    $conn = mysql_connect($server, $username, $password) or die("Error connecting to server: " . mysql_error());
	
	return $conn;
}

/*===================================================================
Close connection to the database
====================================================================*/
function closeDB($conn){
	
	mysql_close($conn);
}

/*
     _______. _______     ___      .______        ______  __    __     .______      ___       _______  _______     _______.
    /       ||   ____|   /   \     |   _  \      /      ||  |  |  |    |   _  \    /   \     /  _____||   ____|   /       |
   |   (----`|  |__     /  ^  \    |  |_)  |    |  ,----'|  |__|  |    |  |_)  |  /  ^  \   |  |  __  |  |__     |   (----`
    \   \    |   __|   /  /_\  \   |      /     |  |     |   __   |    |   ___/  /  /_\  \  |  | |_ | |   __|     \   \    
.----)   |   |  |____ /  _____  \  |  |\  \----.|  `----.|  |  |  |    |  |     /  _____  \ |  |__| | |  |____.----)   |   
|_______/    |_______/__/     \__\ | _| `._____| \______||__|  |__|    | _|    /__/     \__\ \______| |_______|_______/    
                                                                                                                           
*/
/*===================================================================
Get the deceased record 
====================================================================*/
function getDeceasedRecord($id){
	$query = "
		SELECT DC.int_deceased_ID AS DCID, 
			CONCAT(DC.vchar_dec_First_Name, ' ', DC.vchar_dec_Last_Name) AS DCFullName, 
			DC.char_gender AS DCGender, 
			DC.vchar_dec_Street_Address AS DCAddress, 
			DC.vchar_dec_City AS DCCity, 
			DC.char_dec_State AS DCState, 
			DC.vchar_dec_Zipcode AS DCZip, 
			CONCAT(PC.vchar_primCont_First_Name, ' ', PC.vchar_primCont_Last_Name) AS PCFullName, 
			PC.nvarchar_primCont_Email AS PCEmail, 
			PC.char_relation_To_Deceased AS PCRelation, 
			PC.vchar_primCont_Phone_Num AS PCPhone, 
			DC.dt_Date_Of_Death AS DCPassingDate, 
			DC.dt_date_Of_Wake_FH AS DCDateWakeFH, 
			DC.time_start_Of_Wake_FH AS DCStartTimeWakeFH, 
			DC.time_end_Of_Wake_FH AS DCEndTimeWakeFH, 
			DC.dt_date_Of_Wake_CH AS DCDateWakeCH, 
			DC.time_start_Of_Wake_CH AS DCStartTimeWakeCH, 
			DC.time_end_Of_Wake_CH AS DCEndTimeWakeCH, 
			DC.dt_date_Of_Mass AS DCMassDate, 
			DC.time_start_Of_Mass AS DCMassTime, 
			DC.longtext_cemetery_Text AS DCCemetery, 
			CONCAT(FMP.vchar_Priest_First_Name, ' ', FMP.vchar_Priest_Last_Name) AS FMPPriestFullName, 
			CONCAT(FMP.vchar_BM_First_Name, ' ', FMP.vchar_BM_Last_Name) AS FMPBMFullName 
		FROM 
			Primary_Contact AS PC 
				INNER JOIN Deceased AS DC ON PC.int_deceased_ID = DC.int_deceased_ID 
				INNER JOIN Funeral_Mass_Plan AS FMP ON DC.int_deceased_ID = FMP.int_deceased_ID 
		WHERE DC.int_deceased_ID=" . $id;
	
	$results = mysql_query($query) or die(mysql_error());	
	$numRows = mysql_num_rows($results);
	
	/*Check if the number of results for the query results 0
		if so, display appropriate message.
		Else, Continue generating the results.*/
	if($numRows <= 0){
		
		$DCFullName = "Nothing to show here";
	}
	else{
		while ($row = mysql_fetch_array($results)) {
			$DCFullName = $row['DCFullName'];
			$DCGender = $row['DCGender'];
			$DCAddress = $row['DCAddress'];
			$DCCity = $row['DCCity'];
			$DCState = $row['DCState'];
			$DCZip = $row['DCZip'];
			
			$PCFullName = $row['PCFullName'];
			$PCEmail = $row['PCEmail'];
			$PCRelation = $row['PCRelation'];
			$PCPhone = $row['PCPhone'];
			
			$DCPassingDate = $row['DCPassingDate'];
			$DCDateWakeFH = $row['DCDateWakeFH'];
			$DCStartTimeWakeFH = $row['DCStartTimeWakeFH'];
			$DCEndTimeWakeFH = $row['DCEndTimeWakeFH'];
			$DCDateWakeCH = $row['DCDateWakeCH'];
			$DCStartTimeWakeCH = $row['DCStartTimeWakeCH'];
			$DCEndTimeWakeCH = $row['DCEndTimeWakeCH'];
			$DCMassDate = $row['DCMassDate'];
			$DCMassTime = $row['DCMassTime'];
			$DCCemetery = $row['DCCemetery'];
			
			$FMPPriestFullName = $row['FMPPriestFullName'];
			$FMPBMFullName= $row['FMPBMFullName'];
		}
	}		
	
	$result = "";
	
	if($numRows <= 0){ 
		$result .= '
		<div class="row">
			<div class="col-12">
				<br>
				<h2 class="text-center">' . $DCFullName . '</h2>
				<br>
			</div>
		</div>';
	}
	else{
		//Format the possibe null options as 'N/A' and list out full gender term
		if($DCGender == 'M'){
			$DCGender = 'Male';	
		}
		else if($DCGender == 'F'){
			$DCGender = 'Female';
		}
				
		if($DCDateWakeFH == '0000-00-00'){
			$DCDateWakeFH = 'N/A';	
		}
		else{
			$DCDateWakeFH = strtotime($DCDateWakeFH);
			$DCDateWakeFH = date('n/d/Y', $DCDateWakeFH);
		}
		if($DCStartTimeWakeFH == '00:00:00'){
			$DCStartTimeWakeFH = 'N/A';	
		}
		else{
			$DCStartTimeWakeFH = strtotime($DCStartTimeWakeFH);
			$DCStartTimeWakeFH = date('g:i A', $DCStartTimeWakeFH);
		}
		if($DCEndTimeWakeFH == '00:00:00'){
			$DCEndTimeWakeFH = 'N/A';	
		}
		else{
			$DCEndTimeWakeFH = strtotime($DCEndTimeWakeFH);
			$DCEndTimeWakeFH = date('g:i A', $DCEndTimeWakeFH);
		}
				
		if($DCDateWakeCH == '0000-00-00'){
			$DCDateWakeCH = 'N/A';	
		}
		else{
			$DCDateWakeCH = strtotime($DCDateWakeCH);
			$DCDateWakeCH = date('n/d/Y', $DCDateWakeCH);	
		}
		if($DCStartTimeWakeCH == '00:00:00'){
			$DCStartTimeWakeCH = 'N/A';	
		}
		else{
			$DCStartTimeWakeCH = strtotime($DCStartTimeWakeCH);
			$DCStartTimeWakeCH = date('g:i A', $DCStartTimeWakeCH);		
		}
		if($DCEndTimeWakeCH == '00:00:00'){
			$DCEndTimeWakeCH = 'N/A';	
		}
		else{
			$DCEndTimeWakeCH = strtotime($DCEndTimeWakeCH);
			$DCEndTimeWakeCH = date('g:i A', $DCEndTimeWakeCH);			
		}
				
		if($DCCemetery == ''){
			$DCCemetery = 'N/A';	
		}
				
		//Use this to format the following dates as m/dd/yyyy
		$DCPassingDate = strtotime($DCPassingDate);
		$DCPassingDate = date('n/d/Y', $DCPassingDate);
		$DCMassDate = strtotime($DCMassDate);
		$DCMassDate = date('n/d/Y', $DCMassDate);
			
		//Use this to format the mass time 
		$DCMassTime = strtotime($DCMassTime);
		$DCMassTime = date('g:i A', $DCMassTime);
		
		
		$result .= '
			<div class="row">
				<div class="col-12">
					<br>
					<div class="push-left push-right">
						<div>
							<p class="heading">' . $DCFullName . '</p>
						</div>
						<div class="d-inline-block">
							<p>
								<strong>Gender: </strong>' . $DCGender 
								. '<br> 
								<strong>Address: </strong>' . $DCAddress . ' ' . $DCCity . ' ' . $DCState . ', ' . $DCZip
							. '&nbsp; &nbsp;<br></p>
						</div>
						<div class="d-inline-block push-right">
							<p>' 
								. '<strong>Passing Date: &nbsp;</strong>' . $DCPassingDate 
								. '<br>'
								. '<strong>Mass Date: &nbsp; &nbsp; &nbsp;</strong>' . $DCMassDate . ', ' . $DCMassTime
							. '</p>
						</div>
					</div>
					<br>
				</div>
				
				<div class="col-12">
					<br>
					<div class="push-left">
						<p class="heading">Wake Info</p>
					</div>
					<div class="d-inline-block push-left">
						<p><strong>Funeral Home: </strong>';
						
						/*If there is no wake in the funeral home, then print 'N/A',
							otherwise print all the info*/
						if($DCDateWakeFH == 'N/A'){
							$result .= 'N/A</p>';
						}
						else{
							$result .= $DCDateWakeFH . ', ' . $DCStartTimeWakeFH . ' - ' . $DCEndTimeWakeFH . '</p>';
						}
					$result .= '
					</div>
					<div class="d-inline-block push-left push-right">
						<p><strong>Church: </strong>';
						
						/*If there is no wake in the church, then print 'N/A',
							otherwise print all the info*/
						if($DCDateWakeCH == 'N/A'){
							$result .= 'N/A</p>';
						}
						else{
							$result .= $DCDateWakeCH . ' | ' . $DCStartTimeWakeCH . ' - ' . $DCEndTimeWakeCH . '</p>';
						}
					$result .= '
					</div>
					<br>
					<br>
				</div>
				
				<div class="col-12">
					<br>
					<div class="push-left">
						<p class="heading">Contact</p>
					</div>
					<div class="d-inline-block push-left">
						<p class="d-inline-block">
							<strong>Name: </strong>' . $PCFullName 
							. '<br>
							<strong>CRelation: </strong>' . $PCRelation
						. '</p>
					</div>
					<div class="d-inline-block push-left push-right">
						<p>
							<strong>Phone: </strong>' . $PCPhone 
								. '<br>
							<strong>Email: </strong>' . $PCEmail
						. '</p>
					</div>
					<br>
					<br>
				</div>
				<div class="col-12">
					<br>
					<div class="push-left push-right">
						<p class="heading">Cemetery Notes</p>
						<p>' . $DCCemetery . '</p>
					</div>
				</div>
				<br>
				<br>
				<div class="col-sm-2 col-md-2 hidden-xs-down"></div>
				<div class="col-12 col-sm-4 col-md-4">
					<div class="form-group push-left push-right">
						<a href="showRecord.php?st=fmp&dec=' . $id . '">
							<button type="button" class="btn btn-lg btn-green form-control">View Funeral Plan</button>
						</a>
					</div>
					<br>
				</div>
				<div class="col-12 col-sm-4 col-md-4">
					<div class="form-group push-left push-right">
						<a href="editDeceasedRecord.php?dec=' . $id . '">
							<button type="button" class="btn btn-lg btn-green form-control">Edit Record</button>
						</a>
					</div>
					<br>
				</div>
				<div class="col-sm-2 col-md-2 hidden-xs-down"></div>
			</div>';
	}
	
	echo $result;
}

/*===================================================================
Get the funeral mass plan record 
====================================================================*/
function getMassPlanRecord($id){
	$query = "
	SELECT
		DC.vchar_dec_First_Name AS DCFirstName,
		DC.vchar_dec_Last_Name AS DCLastName,
		DC.char_gender AS DCGender, 
		DC.vchar_dec_Street_Address AS DCAddress, 
		DC.vchar_dec_City AS DCCity, 
		DC.char_dec_State AS DCState, 
		DC.vchar_dec_Zipcode AS DCZip, 
		DC.dt_Date_Of_Death AS DCPassingDate, 
		DC.dt_date_Of_Mass AS DCMassDate,
		DC.time_start_Of_Mass AS DCMassTime, 
		DC.longtext_family_Members AS DCFamilyMembers,
		FMP.longtext_pall_Placers AS FMPPallPlacers,
		FMP.longtext_personal_Reminiscences AS FMPReminiscences,
		FMP.vchar_first_reader_FName AS FMPFirstReaderFName,
		FMP.vchar_first_reader_LName AS FMPFirstReaderLName,
		FirstR.vchar_title AS FMPFirstReading,
		FMP.vchar_second_reader_FName AS FMPSecondReaderFName,
		FMP.vchar_second_reader_LName AS FMPSecondReaderLName,
		SecondR.vchar_title AS FMPSecondReading,
		GospelR.vchar_title AS FMPGospelReading,
		FaithfulR.vchar_title AS FMPFaithfulReading,
		MoF.vchar_song_Name AS FMPMoF,
		Proc.vchar_song_Name AS FMPProc,
		RP.vchar_song_Name AS FMPRP,
		GA.vchar_song_Name AS FMPGA,
		PoG.vchar_song_Name AS FMPPoG,
		Comm.vchar_song_Name AS FMPComm,
		FC.vchar_song_Name AS FMPFC,
		Rece.vchar_song_Name AS FMPRece,
		EfC.vchar_song_Name AS FMPEfC	
	FROM (((((((((((((((Funeral_Mass_Plan as FMP 
		INNER JOIN Song AS MoF ON MoF.int_Song_ID = FMP.int_Mystery_Of_Faith_Song_ID) 
		INNER JOIN Song AS Proc ON Proc.int_Song_ID = FMP.int_Processional_Song_ID)
		INNER JOIN Song AS RP ON RP.int_Song_ID = FMP.int_Responsorial_Psalm_Song_ID) 
		INNER JOIN Song AS GA ON GA.int_Song_ID = FMP.int_Gospel_Acclamation_Song_ID) 
		INNER JOIN Song AS PoG ON PoG.int_Song_ID = FMP.int_Preparation_of_Gifts_Song_ID) 
		INNER JOIN Song AS Comm ON Comm.int_Song_ID = FMP.int_Communion_Song_ID) 
		INNER JOIN Song AS FC ON FC.int_Song_ID = FMP.int_Final_Commendation_Song_ID) 
		INNER JOIN Song AS Rece ON Rece.int_Song_ID = FMP.int_Recessional_Song_ID)
		LEFT OUTER JOIN Song AS EfC ON EfC.int_Song_ID = FMP.int_Especially_For_Children_Song_ID)
		INNER JOIN Reading_Prayer as FirstR ON FirstR.int_Reading_ID = FMP.int_first_reading_ID)
		INNER JOIN Reading_Prayer as SecondR ON SecondR.int_Reading_ID = FMP.int_second_reading_ID)
		INNER JOIN Reading_Prayer as GospelR ON GospelR.int_Reading_ID = FMP.int_gospel_reading_ID)
		INNER JOIN Reading_Prayer as FaithfulR ON FaithfulR.int_Reading_ID = FMP.int_prayer_Faithfu_reading_ID)
		INNER JOIN Deceased as DC ON DC.int_deceased_ID = FMP.int_deceased_ID)
		INNER JOIN Primary_Contact AS PC ON PC.int_deceased_ID = FMP.int_deceased_ID)
	WHERE FMP.int_deceased_ID=" . $id;
	
	$results = mysql_query($query) or die(mysql_error());	
	$numRows = mysql_num_rows($results);
	
	/*Check if the number of results for the query results 0
		if so, display appropriate message.
		Else, Continue generating the results.*/
	if($numRows <= 0){
		
		$result = "Nothing to show here";
	}
	else{
		while ($row = mysql_fetch_array($results)) {
			$DCFirstName = $row['DCFirstName'];
			$DCLastName = $row['DCLastName'];
			$DCGender = $row['DCGender'];
			$DCAddress = $row['DCAddress'];
			$DCCity = $row['DCCity'];
			$DCState = $row['DCState'];
			$DCZip = $row['DCZip'];
			$DCFamilyMembers = $row['DCFamilyMembers'];
			
			$FMPPallPlacers = $row['FMPPallPlacers'];
			$FMPReminiscences = $row['FMPReminiscences'];
			$FMPFirstReaderFName = $row['FMPFirstReaderFName'];
			$FMPFirstReaderLName = $row['FMPFirstReaderLName'];
			$FMPFirstReading = $row['FMPFirstReading'];
			$FMPSecondReaderFName = $row['FMPSecondReaderFName'];
			$FMPSecondReaderLName = $row['FMPSecondReaderLName'];
			$FMPSecondReading = $row['FMPSecondReading'];
			$FMPGospelReading = $row['FMPGospelReading'];
			$FMPFaithfulReading = $row['FMPFaithfulReading'];
			$FMPMoF = $row['FMPMoF'];
			$FMPProc = $row['FMPProc'];
			$FMPRP = $row['FMPRP'];
			$FMPGA = $row['FMPGA'];
			$FMPPoG = $row['FMPPoG'];
			$FMPComm = $row['FMPComm'];
			$FMPFC = $row['FMPFC'];
			$FMPRece = $row['FMPRece'];
			$FMPEfC = $row['FMPEfC'];
		}
		
		//Use this to display full gender term
		if($DCGender == 'M'){
			$DCGender = 'Male';	
		}
		else if($DCGender == 'F'){
			$DCGender = 'Female';
		}
		
		//Use this to format the following dates as m/dd/yyyy
		$DCPassingDate = strtotime($DCPassingDate);
		$DCPassingDate = date('n/d/Y', $DCPassingDate);
		$DCMassDate = strtotime($DCMassDate);
		$DCMassDate = date('n/d/Y', $DCMassDate);
		
		$familyMembers = explode("|", $DCFamilyMembers);
		$pallPlacers = explode("|", $FMPPallPlacers);
		$reminiscences = explode("|", $FMPReminiscences);
		
		//Use this to format the mass time 
		$DCMassTime = strtotime($DCMassTime);
		$DCMassTime = date('g:i A', $DCMassTime);
		
		$result .= '
			<div class="row">
				<div class="col-12">
					<br>
					<div class="push-left push-right">
						<div>
							<p class="heading">' . $DCFirstName . ' ' . $DCLastName . '</p>
						</div>
						<div class="d-inline-block">
							<p>
								<strong>Gender: </strong>' . $DCGender 
								. '<br> 
								<strong>Address: </strong>' . $DCAddress . ' ' . $DCCity . ' ' . $DCState . ', ' . $DCZip
							. '&nbsp; &nbsp;<br></p>
						</div>
						<div class="d-inline-block push-right">
							<p>' 
								. '<strong>Passing Date: &nbsp;</strong>' . $DCPassingDate 
								. '<br>'
								. '<strong>Mass Date: &nbsp; &nbsp; &nbsp;</strong>' . $DCMassDate . ', ' . $DCMassTime
							. '</p>
						</div>
					</div>
					<br>
				</div>
				<div class="col-12">
					<br>
					<div class="push-left">
						<p class="heading">Family</p>
					</div>';
		
				for($i = 0; $i < count($familyMembers); $i++){
					if($i % 4 == 0){
						if($i != 0){
							$result .= '</p>';
						}
						$result .= '<p class="push-left"><strong>' . ($i + 4) / 4 . ') </strong>';
					}
					
					$result .= $familyMembers[$i] . ' ';	
					
					if(($i + 1) % 2 == 0 || ($i + 1) % 3 == 0){
						$result .= '| ';
					}
				}		
		
			$result .= '
					<br>
					<br>
				</div>
				<div class="col-12">
					<br>
					<div class="push-left">
						<p class="heading">Pall Placers</p>
					</div>';
				for($i = 0; $i < count($pallPlacers); $i++){
					$result .= '<p class="push-left"><strong>' . ($i + 1) . ')</strong> ' . $pallPlacers[$i] . '</p>';
				}
			$result .=	'
					<br>
				</div>
				<div class="col-12 col-md-6">
					<br>
					<div class="push-left">
						<p class="heading">First Reading</p>
					</div>
					<div class="push-left">
						<p><strong>Reading: </strong>' . $FMPFirstReading . '<br>
							<strong>Reader: </strong>' . $FMPFirstReaderFName . ' ' . $FMPFirstReaderLName . '</p> 
					</div>
					<br>
				</div>
				<div class="col-12 col-md-6">
					<br>
					<div class="push-right push-left">
						<p class="heading">Second Reading</p>
					</div>
					<div class="push-right push-left">
						<p><strong>Reading: </strong>' . $FMPSecondReading . '<br>
							<strong>Reader: </strong>' . $FMPSecondReaderFName . ' ' . $FMPSecondReaderLName . '</p> 
					</div>
					<br>
				</div>
				<div class="col-12 col-md-6">
					<br>
					<div class="push-left">
						<p class="heading">Gospel Reading</p>
					</div>
					<div class="push-left">
						<p><strong>Reading: </strong>' . $FMPGospelReading . '</p> 
					</div>
					<br>
				</div>
				<div class="col-12 col-md-6">
					<br>
					<div class="push-right push-left">
						<p class="heading">Prayers of the Faithful</p>
					</div>
					<div class="push-right push-left">
						<p><strong>Reading: </strong>' . $FMPFaithfulReading . '</p> 
					</div>
					<br>
				</div>
				<div class="col-12">
					<br>
					<div class="push-left">
						<p class="heading">Music</p>
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-left">
						<p><strong>Communion Song: </strong>' . $FMPComm . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-right push-left">
						<p><strong>Responsorial Psalm: </strong>' . $FMPRP . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-left">
						<p><strong>Final Commendation: </strong>' . $FMPFC . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-right push-left">
						<p><strong>Gospel Acclamation: </strong>' . $FMPGA . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-left">
						<p><strong>Recessional Song: </strong>' . $FMPRece . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-right push-left">
						<p><strong>Mystery of Faith: </strong>' . $FMPMoF . '</p> 
					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="push-left">
						<p><strong>Preperation of Gifts: </strong>' . $FMPPoG . '</p> 
					</div>
					<br>
				</div>
				<div class="col-12">
					<br>
					<div class="push-left push-right">
						<p class="heading">Personal Reminiscences</p>
					</div>
					<div class="push-left push-right">
						<p><strong>How Did Your Loved One Practice His or Her Faith?</strong></p>
						<p>' . $reminiscences[0] . '</p>
						<br>
					</div>
					<div class="push-left push-right">
						<p><strong>How Does the Gospel Reading You Chose Relate to the Deceased?</strong></p>
						<p>' . $reminiscences[1] . '</p>
						<br>
					</div>
					<div class="push-left push-right">
						<p><strong>What Memories or Other Pieces of Personal Information Would You Like to Share About Your Loved One?</strong></p>
						<p>' . $reminiscences[2] . '</p>
						<br>
					</div>
					<br>
				</div>
				<div class="col-sm-2 col-md-4 hidden-xs-down"></div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="form-group push-left push-right">
						<a href="showRecord.php?st=dec&dec=' . $id . '">
							<button type="button" class="btn btn-lg btn-green form-control">Deceased Record</button>
						</a>
					</div>
					<br>
				</div>
				<div class="col-sm-2 col-md-4 hidden-xs-down"></div>
			</div>';
	}
	
	echo $result;
	
}

/*
 _______   ______     ______   .___________. _______ .______      
|   ____| /  __  \   /  __  \  |           ||   ____||   _  \     
|  |__   |  |  |  | |  |  |  | `---|  |----`|  |__   |  |_)  |    
|   __|  |  |  |  | |  |  |  |     |  |     |   __|  |      /     
|  |     |  `--'  | |  `--'  |     |  |     |  |____ |  |\  \----.
|__|      \______/   \______/      |__|     |_______|| _| `._____|
*/
/*===================================================================
Generate the site footer
====================================================================*/
function getFooter(){
	echo 
	'<br class="hidden-xs-down">
	<br class="hidden-xs-down">
	<br class="hidden-xs-down">
	<div class="row fullFooter">
		<div class="col-12 col-sm-6 col-md-3 footer-push-left footer-push-right">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<p class="footerHeader"><a class="noMarkup" href="https://www.stjuliana.org"><strong>HOME</strong></a></p>
			<br>
			<p>
				<a class="noMarkup" href="https://www.stjuliana.org/bulletins">BULLETINS</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/events/upcoming">EVENTS</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/reaching-us">CONTACT US</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/faith-life/mass">MASS TIMES</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/search">SEARCH</a>
			</p>
			<br>
			<br>
		</div>
		<div class="col-12 col-sm-6 col-md-3 footer-push-left footer-push-right">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<p class="footerHeader"><a class="noMarkup" href="https://www.stjuliana.org/church"><strong>CHURCH</strong></a></p>
			<br>
			<p>
				<a class="noMarkup" href="https://www.stjuliana.org/belonging">BELONGING</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/events/faith-life">FAITH & PRAYER</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/giving">GIVING</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/church">LEARNING</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/pastoral-council">SERVING</a>
			</p>
			<br>
			<br>
		</div>
		<div class="col-12 col-sm-6 col-md-3 footer-push-left footer-push-right">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<p class="footerHeader"><a class="noMarkup" href="https://www.stjuliana.org/school"><strong>SCHOOL</strong></a></p>
			<br>
			<p>
				<a class="noMarkup" href="https://www.stjuliana.org/curriculum">ACADEMICS</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/events/admissions">ADMISSIONS</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/faith">FAITH</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/parents">PARENTS</a>
				<br>
				<br>
				<a class="noMarkup" href="https://www.stjuliana.org/students">STUDENTS</a>
			</p>
			<br>
			<br>
		</div>
		<div class="col-12 col-sm-6 col-md-3 footer-push-left footer-push-right">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<br class="hidden-sm-up">
			<p><a class="noMarkup" href="https://www.stjuliana.org/reaching-us">SAINT JULIANA PARISH</a></p>
			<p>7200 N OSCEOLA AVE</p>
			<p>CHICAGO IL 60631</p>
			<p>773.631.4127</p>
			<p><a class="noMarkup" href="https://www.stjuliana.org/reaching-us">EMAIL</a></p>
			<br>
			<p class="footerHeader"><a class="noMarkup" href="https://www.stjuliana.org/#modal-b"><strong>SITE FEEDBACK</strong></a></p>
			<br>
		</div>
		<div class="col-12 footer-push-left footer-push-right">
			<div class="text-sm-right">
				<ul class="list-inline">
					<li class="list-inline-item icon-push">
						<a class="noMarkup" href="https://www.stjuliana.org/search"><i class="fas fa-2x fa-search"></i></a>
					</li>
					<li class="list-inline-item icon-push">
						<a class="noMarkup" href="https://www.facebook.com/StJulianaParish"><i class="fab fa-2x fa-facebook-f"></i></a>
					</li>
					<li class="list-inline-item icon-push">
						<a class="noMarkup" href="https://www.instagram.com/stjulianaparish"><i class="fab fa-2x fa-instagram"></i></a>
					</li>
					<li class="list-inline-item icon-push">
						<a class="noMarkup" href="http://www.twitter.com/StJuliana"><i class="fab fa-2x fa-twitter"></i></a>
					</li>
					<li class="list-inline-item icon-push">
						<a class="noMarkup" href="https://www.givecentral.org/location/116"><i class="fas fa-2x fa-gift"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</div>';
}

?>